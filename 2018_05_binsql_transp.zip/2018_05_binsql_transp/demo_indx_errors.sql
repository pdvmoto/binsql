/*

demo a few often-used errors, notably why indexes are not used

 - like %
 - type-casts
 - concatenate
 - not-exist
 - skip-scan  (dble check: depends on statistics, A/P behave different)
 - histograms
 - ansi...

*/

alter session set optimizer_mode = first_rows;

set echo on
set pagesize 100
set linesize 100
column table_name format A30


alter session set optimizer_mode = first_rows;

set sqlprompt "SQL> "

set echo on
set pagesize 100
set linesize 100
column table_name format A30


spool demo_indx_errors

clear screen

-- drop and recreate the table with a 2-field PK, typical parent-child.

drop   table OVL;
create table OVL as 
select OWNER, TABLE_NAME, TABLESPACE_NAME
     , IOT_TYPE, IOT_NAME, NUM_ROWS, AVG_ROW_LEN
     , LAST_ANALYZED, STATUS
from all_tables order by dbms_random.value ;


-- 
-- table with some fields..
-- now some SQL on that table to demonstrate how to explain and trace...
-- 

accept press_enter prompt "press enter to continue..."

select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--	
-- notice the full table access, why no indexes ?
--
accept press_enter prompt "press enter to continue..."


set autotrace on stat 
select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
set autotrace off

-- 
-- Notice the autotrace information: consistent-gets.
-- 

accept press_enter prompt "Add index and constraint. enter to continue..."


create unique index OVL_PK on OVL ( OWNER, TABLE_NAME );
alter table OVL add constraint OVL_PK 
primary key ( OWNER, TABLE_NAME ) using index ovl_pk ;

-- Index and constraint added.
-- first pass of the qry is a good moment to use display_cursor.
-- second pass of the qry we will use autotrace-stats to see IO.
accept press_enter prompt "press enter to continue..."

select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- notice the access via PK-range, followed by access-by-idx-rowid
--
accept press_enter prompt "press enter to continue..."

set autotrace on stat 
select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
set autotrace off

--
-- notice the nr of consistent-gets:
-- the query is now able to filter its set based on the index 
-- but then has to visit the table to pickup the num_rows...
-- (removing num_rows, we could reduce nr of gets..)
--
accept press_enter prompt "press enter to continue..."


clear screen

-- LIKE % ------------------------------------------

--
-- demo-case: the use or abuse of like-%
-- the LIKE-% operator is most-usefull at the END of a field.
--
-- Think of phone-book analogy: searching for SMIT% is easy. 
-- searching for %ITH is hard.
--
accept press_enter prompt "press enter to continue..."


--
-- select over index using %

select owner, table_name, num_rows 
from ovl
where owner like 'DBSNM%'
and table_name like 'B%'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));    

--
-- notice the use of index,
-- next run will show how much consistent-gets..
--
accept press_enter prompt "press enter to continue..."

set autotrace on stat
select owner, table_name, num_rows 
from ovl
where owner like 'DBSNM%'
and table_name like 'B%'
/
set autotrace off

--
-- ... and check nr of consisent-gets.
-- this is OK-ish !
-- Oracle uses the index to do all of the filtering.
-- (still has to visit the table to pick up the num_rows)
--
-- but what if we ask for something different?
-- 
	
accept press_enter prompt "press enter to continue..."

select owner, table_name, num_rows 
from ovl
where owner like '%SNMP'
and table_name like 'B%'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- no more index. because there is no good "alphabetical search" on %A%
-- check nr of consistent gets
-- 

accept press_enter prompt "press enter to continue..."

set autotrace on stat
select owner, table_name, num_rows 
from ovl
where owner like '%SNMP'
and table_name like 'B%'
/
set autotrace off

--
-- much more gets, full table scan...
-- 
-- the condition  %SNMP made it impossible to use the index.
--
-- note: theoretically,  notably when we removed num_rows, 
-- oracle can revert to a (faster) full scan of the index
--
--

accept press_enter prompt "press enter to continue..."


select owner, table_name -- , num_rows 
from ovl
where owner like '%SNMP'
and table_name like 'B%'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- check. now the SQL only needs the index. But the whole index.
--
--
accept press_enter prompt "press enter to continue..."


set autotrace on stat
select owner, table_name -- , num_rows 
from ovl
where owner like '%SNMP'
and table_name like 'B%'
/
set autotrace off

--
-- nr of gets would correspond to the (used) size of index.
-- 
accept press_enter prompt "press enter to continue..."

clear screen

-- 
-- now for skip scan. (doesnt work on this demo/version ?? ) ---------- 
-- 
-- 
select owner, table_name -- , num_rows 
from ovl
where owner like '%SNMP'
and table_name = 'BSLN_BASELINES'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

-- 

clear screen

-- now try concatenate ---------------------------

select owner, table_name, num_rows 
from ovl
where owner||'.'||table_name = 'DBSNMP.BSLN_BASELINES'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        


--
-- notice the full scan
--

accept press_enter prompt "press enter to continue..."


set autotrace on stat
select owner, table_name, num_rows 
from ovl
where owner||'.'||table_name = 'DBSNMP.BSLN_BASELINES'
/
set autotrace off

--
-- much preferabl to put both fields as where-equal...
--
--

accept press_enter prompt "press enter to continue..."


select owner, table_name, num_rows 
from ovl
where owner    = 'DBSNMP'
and table_name = 'BSLN_BASELINES'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        


accept press_enter prompt "press enter to continue..."

set autotrace on stat
select owner, table_name, num_rows 
from ovl
where owner    = 'DBSNMP'
and table_name = 'BSLN_BASELINES'
/
set autotrace off

--
-- suddenly very efficient..
--

accept press_enter prompt "press enter to continue..."


clear screen

-- type-casting ------------------------------------------

-- some short demos
-- on a record subset of meas_pf ..

-- 
--
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where m.mutnr = 70861635  
and m.ccy_id ='EUR'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- OK: this stmnt can use an index.
--

accept press_enter prompt "press enter to continue..."

set autotrace on stat
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where m.mutnr = 70861635  
and m.ccy_id ='EUR'
/
set autotrace off

--
-- the search over index is efficient...
--

accept press_enter prompt "press enter to continue..."

--
-- error1: almost error: type mismatch
--
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where m.mutnr = '70861635'
and m.ccy_id ='EUR'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- luckily, the database can do the type-conversion..
--
accept press_enter prompt "press enter to continue..."

--
-- error1-bis, fixing type-mismatch on the field-side doesnt help
-- 
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where to_char ( m.mutnr ) = '70861635'
and m.ccy_id ='EUR'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        
 
-- 
-- the index is on mutnr, not on the to-char-converted mutnr.
-- and sometimes you notice the "hiccup".
-- check nr of consistent-gets...

accept press_enter prompt "press enter to continue..."

set autotrace on stat
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where to_char ( m.mutnr ) = '70861635'
and m.ccy_id ='EUR'
/
set autotrace off

--
-- how much effort to skip-scan the index... ?
-- (sometimes optimizer even decides to do Full-table)
--

accept press_enter prompt "press enter to continue..."

-- error2: cannot use index in mutnr: concat
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where 'nr='||m.mutnr  = 'nr=70861635' 
and m.ccy_id ='EUR'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- again: sub-optimal use of index, 
-- where-expression is not an indexed-expression.
--

accept press_enter prompt "press enter to continue..."

-- but (error3+correction)this will work: numeric-column = numeric-expression
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where m.mutnr+1  = 70861636
and m.ccy_id ='EUR'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- cannot use mutnr from the index.
-- where-clause contains expression that "isnt indexes" 
-- but.. in this case, you can think of a solution.
--
accept press_enter prompt "press enter to continue..."


select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where m.mutnr  = 70861636-1
and m.ccy_id ='EUR'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- back to correct use of index.
-- because: Where-clause contains the index-expression.
--
accept press_enter prompt "press enter to continue..."

set autotrace on stat
select m.mutnr, m.idp, m.secgrp, m.ccy_id 
from SAMCO_MAIN.meas_pf m
where m.mutnr  = 70861636-1
and m.ccy_id ='EUR'
/
set autotrace off

accept press_enter prompt "press enter to continue..."


-- 
-- THE END (for now)
--


*/	


/* now devise a demo for the cases of in/exist/not-in/not-exist and union
*/

