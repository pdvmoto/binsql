

-- notice how a different table comes out on top when chaning nr of rows.

select table_name 
from all_tables
where rownum < 2
order by table_name;


select table_name 
from all_tables
where rownum < 5
order by table_name;

-- hence, using rownum combined with order-by is RISKY.
-- this is a known issue, and is fixable using rank() etc... but still....
