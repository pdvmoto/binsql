set heading off
set feedback off
set linesize 160

column dir_name format A40
column file_name format A15
column tablespace_name format A10 
column sze format A10

spool cp_files.sh
SELECT '# Use Copydir parameter to make a full backup to one copydir!'
FROM DUAL;

SELECT '# Make sure this directory exists!'
FROM DUAL;

SELECT 'COPY_DIR=/oradata/cxx/'||name
FROM v$database;

SELECT  'cp '|| file_name ||' $COPY_DIR/' -- ||rownum||'_'
||substr(file_name,       instr(file_name,'/',-1,1) + 1)
FROM dba_data_files
ORDER BY file_id
/

SELECT  'cp '|| file_name ||' $COPY_DIR/' -- ||rownum||'_'
||substr(file_name,       instr(file_name,'/',-1,1) + 1)
FROM dba_temp_files
ORDER BY file_id
/

SELECT  'cp '|| member ||' $COPY_DIR/' -- ||rownum||'_'
||substr(member,      instr(member,'/',-1,1) +    1)
FROM v$logfile 
ORDER BY member
/

SELECT  'cp '|| name ||' $COPY_DIR/' -- ||rownum||'_'
||substr(name,        instr(name,'/',-1,1) +  1)
FROM v$controlfile 
ORDER BY name
/


-- report on sizes..

SELECT  substr(file_name,   1,  instr(file_name,'/',-1,1) - 1)  dir_name
    ,   substr(file_name,   instr(file_name,'/',-1,1) +  1) file_name
    ,   ' = '||lpad(bytes/(1024*1024),4)||' MB' sze 
    ,   tablespace_name
FROM dba_data_files
ORDER BY tablespace_name
, file_name
/

SET heading off

SELECT '                   Total of ' || count (*) || '  datafiles   = '
||sum(bytes/(1024*1024))||' MB' 
FROM v$datafile
/

SET heading on

SELECT  substr(file_name,   1,  instr(file_name,'/',-1,1) - 1)  dir_name
    ,   substr(file_name,   instr(file_name,'/',-1,1) +  1) file_name
    ,   ' = '||lpad(bytes/(1024*1024),4)||' MB' sze 
    ,   tablespace_name
FROM dba_temp_files
ORDER BY tablespace_name
, file_name
/

SET heading off

SELECT '                   Total of ' || count (*) || '  datafiles   = '
||sum(bytes/(1024*1024))||' MB' 
FROM v$tempfile
/

SET heading on

SELECT  substr(member,  1,  instr(member,'/',-1,1) -    1)      dir_name
,     	substr(member, instr(member, '/', -1, 1) +1 )  file_name
        ,   ' = '||lpad((v$log.bytes/(1024*1024)),4)||' MB' sze 
	,   v$logfile.group#
FROM v$logfile, v$log
WHERE v$log.group# = v$logfile.group#
/

SET heading off

SELECT '                     Total of ' || count (*) || ' logfiles    = '
||lpad(sum(members*bytes/(1024*1024)),4)||' MB'  
FROM v$log
/

SET heading on

SELECT  substr(name,    1,  instr(name,'/',-1,1) -  1)  		dir_name
    ,   substr(name,        instr(name,'/',-1,1) +  1)  		file_name
    ,   status
from v$controlfile
/

SELECT '                     Total of ' || count (*) || ' ctlfiles     '
from v$controlfile
/

SPOOL OFF
NEWPAGE
