create table a ( a number ) ;

alter table a add constraint a_pk primary key ( a ) ;

