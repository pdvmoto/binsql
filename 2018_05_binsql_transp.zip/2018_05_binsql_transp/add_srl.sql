
-- standby redos, 1 more (minimum), or 1 extra group per thread (recommended)

alter database add standby logfile ( 'C:\ORACLE\ORADATA\DB12\REDO01.SRL' ) size 5m; 
alter database add standby logfile ( 'C:\ORACLE\ORADATA\DB12\REDO02.SRL' ) size 5m; 
alter database add standby logfile ( 'C:\ORACLE\ORADATA\DB12\REDO03.SRL' ) size 5m; 
alter database add standby logfile ( 'C:\ORACLE\ORADATA\DB12\REDO04.SRL' ) size 5m; 
