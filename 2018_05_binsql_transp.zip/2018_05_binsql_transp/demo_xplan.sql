set linesize 100
set pagesize 100 

select * from table(dbms_xplan.display_cursor);        

accept pressanykey prompt "press any key"

select * from table(dbms_xplan.display_cursor('',null,'advanced'));        

