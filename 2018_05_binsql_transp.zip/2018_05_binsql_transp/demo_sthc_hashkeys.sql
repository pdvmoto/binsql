-- get some size-ideas..
-- what happens if we play with the size and hashkeys..

column table_name    format A10
column num_rows      format 99,999,999
column blocks        format 999,999   
column empty_blocks  format 9,999    head empblck
column avg_space     format 9,999    head avgspc
column chain_cnt     format 9,999    head chncnt
column avg_rowlen    format 9,999    head avgrow

column segment_name     format A20
column partition_name   format A25
column bytes         format 99,999,999 
column kbytes        format 99999999 
column extents	     format 9,999


drop table clut ;
drop cluster clu ;
drop cluster clu01 ;
drop cluster clu02 ;
drop cluster clu05 ;
drop cluster clu12 ;
drop cluster clu20 ;

set echo on

create cluster clu01 ( key varchar2(78 byte) ) 
single table hashkeys 100;

create cluster clu02 ( key varchar2(78 byte) ) 
single table hashkeys 200;

create cluster clu05 ( key varchar2(78 byte) ) 
single table hashkeys 500;

create cluster clu12 ( key varchar2(78 byte) ) 
single table hashkeys 1200;

create cluster clu20 ( key varchar2(78 byte) ) 
single table hashkeys 2000;

select segment_name, bytes / (1024 * 1024) as MB, blocks
from user_segments where segment_name like 'CLU%';

set echo off

prompt
prompt NOTE:
prompt If SIZE if ommitted, the cluster seems to grab one block for each hashkey.
prompt
pause Have a look at the sizes and press enter to continue ...

prompt cleaning up...

drop cluster clu01 ;
drop cluster clu02 ;
drop cluster clu05 ;
drop cluster clu12 ;
drop cluster clu20 ;

prompt clean....