
SELECT sys_context('userenv','sid') session_id from dual;

-- update parent_heap set v='upd' where id = 1 ;
update parent_iot set v='upd' where id = 1 ;

--select * from parent_heap where id=1 for update;

-- now go to l2, and try to insert + update child record for p_id=1

