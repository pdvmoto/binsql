
spool demo_sort

drop table aaa ;

create table aaa ( aaa varchar2(10) );


Insert into aaa   (AAA) Values   ('AA');
Insert into aaa   (AAA) Values   ('AB');
Insert into aaa   (AAA) Values   ('aa');
Insert into aaa   (AAA) Values   ('ab');
Insert into aaa   (AAA) Values   ('ba');
Insert into aaa   (AAA) Values   ('BA');
COMMIT;


set echo on
set feedb on

column name		format A35 trunc
column value		format A15 wrap
column dflt		format A4 justify left
column Ses		format A6 head sesmod justify right
column sys		format A6 trunc head sysmod 

column descript		format A26

doc

	Nls and date related parameters.
#
SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , value 
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		      descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'nls%') 
	OR (p.name Like '%char%')	   
	OR (p.name Like '%date%')	   
	)
ORDER BY p.name
/

select parameter  as name, value
from v$nls_parameters
/

doc
	now do some sorts, 
	mind the different results!
#


select * from aaa order by 1 ;

alter session set nls_sort = german ;

select * from aaa order by 1 ;

alter session set nls_sort = binary ;

select * from aaa order by 1 ;

alter session set nls_sort = dutch ;
 
select * from aaa order by  1;

spool off
