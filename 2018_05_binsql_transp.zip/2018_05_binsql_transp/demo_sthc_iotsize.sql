column table_name    format A10
column num_rows      format 99,999,999
column blocks        format 999,999   
column empty_blocks  format 9,999    head empblck
column avg_space     format 9,999    head avgspc
column chain_cnt     format 9,999    head chncnt
column avg_rowlen    format 9,999    head avgrow

column segment_name     format A20
column partition_name   format A25
column bytes         format 99,999,999 
column kbytes        format 99999999 
column extents	     format 9,999


drop table iotb ;

-- now recreate IOT and fill it with smaller keys.
CREATE TABLE IOTB
(
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint iotb_pk primary key ( key)
)
organization index
/

insert into iotb 
select to_char(num_key), num_key, date_modified, padding from heap ;
commit ;

analyze table iotb compute statistics;

select 
table_name, num_rows, blocks, empty_blocks, avg_space, chain_cnt, avg_row_len, compression
from user_tables
where table_name like upper ( '&1'||'%' )
order by table_name
/

select 
segment_name,  partition_name, bytes / 1024 as kbytes, blocks, extents
from user_segments
where segment_name like upper ( '&1'||'%' )
order by segment_name, partition_name
/



