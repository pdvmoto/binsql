
doc
	scan04.sql
	Transaction volume for last 20 log switches.
	- less then 1000 seconds per switch is "fast",
		consider larger logfiles
	- Last column > 10.00 is considered "high volume"
		examine batches, try to spread (batch) load over time
#

column sec			format 9999
column ch_per_sec	format 99999.999
column kb_per_sec	format 99999.999

select 	
		lh2.time											switch
,		TO_NUMBER ( 	TO_DATE ( lh2.time, 'MM/DD/YY HH24:MI:SS' ) 
					- 	TO_DATE ( lh1.time, 'MM/DD/YY HH24:MI:SS' )
				) * 3600 * 24 								seconds 
,		  ( l.bytes / 1024  )
		/ ( TO_NUMBER ( 	TO_DATE ( lh2.time, 'MM/DD/YY HH24:MI:SS' ) 
						- 	TO_DATE ( lh1.time, 'MM/DD/YY HH24:MI:SS' )
						) * 3600 * 24
			) 												kb_per_sec 
from 	v$log_history lh1
, 		v$log_history lh2
,		v$log		l
where lh1.sequence# = lh2.sequence# -1
and     TO_NUMBER (     TO_DATE ( lh2.time, 'MM/DD/YY HH24:MI:SS' ) 
					-   TO_DATE ( lh1.time, 'MM/DD/YY HH24:MI:SS' )
					) * 3600 * 24  > 0     /* min. 60 avoids hot bck peaks */
and 	l.status = 'CURRENT' 		/* assume  all groups equal file-sizes */
and lh1.sequence# > l.sequence# - 500
order by lh1.sequence# 
/

