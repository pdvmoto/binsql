/*
demo of difference in access on Equal Predicate,
between Heap, IOT and Single-table-hash-cluster (fastest?)

pre-reqs:
 - fairly large table (100M+, but reduced demo to 64K)
 - static, predictable contents.
 - long-ish irregular varchar2 key
 - relatively small records (reduced demo to 20-padding)

Additional ideas:
 - test reverse index as well
 - test multy-key PK (e.g. parent + child)
 - test impact of growing record-size, 
 - test effect of too-many-keys, 
 - test non-equal predicates (the PK index saves the day)
*/

set linesize 120
set pagesize 0
set echo on

drop table   heap ;
drop table   iotb ;
drop table   clut ;
drop cluster clu ;

-- first the heap

create table heap as 
select 
  to_char (to_date ( rownum, 'J'), 'JSP' )  as key  --note the non-random distribution of the key
, rownum  as num_key
, sysdate +  ( dbms_random.value ( -100.0, 100.0) ) as date_modified
, rpad ( to_char ( dbms_random.value ) || ' ' || to_char ( dbms_random.value ), 20 )  as padding
from dual 
connect by level < ( 64 * 1024)
/

create unique index heap_pk on heap ( key ) ;
alter table heap add constraint heap_pk primary key ( key )  ;

-- now IOT
CREATE TABLE IOTB
(
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint iotb_pk primary key ( key)
)
organization index
/

insert into iotb select * from heap ;
commit ;


-- now cluster
-- note: I have used 10000 and 1000 (10k and 1k) for hashkeys, and results are the same..
-- but storage is a lot less on hashkeys 1000 ... ?
create cluster clu ( key varchar2(78 byte) ) 
single table 
hashkeys 10000;

CREATE TABLE clut (
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

insert into clut select * from heap ;
commit ;

-- all objects created and filled..
accept pressanykey prompt "press any key"


select * from heap
where key = 'FIVE HUNDRED' 
/
set autotrace on
/
set autotrace off

accept pressanykey prompt "press any key"

select * from iotb
where key = 'FIVE HUNDRED'
/
set autotrace on
/
set autotrace off

-- notice the IOT is slightly more Efficient...
accept pressanykey prompt "press any key"


select * from clut
where key = 'FIVE HUNDRED'
/
set autotrace on
/
set autotrace off


-- That was the main demo: 
-- but the Cluster does the Absolute Minimal Consistent Gets.
--
-- That was the main demo.
--
-- Now try a few more: select more then one row,
-- and Clusters become equally efficient to the heap-table-with-index....

accept pressanykey prompt "press any key"


select * from heap
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off

accept pressanykey prompt "press any key"


select * from iotb
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off

accept pressanykey prompt "press any key"


select * from clut
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off

accept pressanykey prompt "press any key"
