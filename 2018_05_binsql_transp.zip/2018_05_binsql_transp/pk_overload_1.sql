/*

file : pk_overload_1

Demonstrate : 
 - Extra field in index.
 - how PK or unique constraint can be enforced with non-unique index.
 - how to save on index-to-table access to reduce logical IO.
 
When to use this trick:
 - if table-access is on PK or other index, but _always_ requires extra field.
   example: parent-child records where a "status" or "date" is used to include/exclude records

actions in the script:
 - create table based on dba_tables user=parent, table_name=child, pk is 2 fields
 - demonstrate that a qry by index does a lot of gets to fetch individual rows.
 - overload the index, show it can still enforce PK
 - Demonstrate that an overloaded index results in index-only access.
 - then demonstrate the additional selectivity, even when table-access is still needed.

Moral:
 - you can add to PK indexes, for example a "status" field.
 - index-only access can be considerably less costly.

todo:
 - consider a nicer, shorter xplan plan output.
 - make sure all xplan calls are the same.
 - consider using just autotrace (too much extra output)
 - beware of CPU-costing warning

other notes:
 - in case of doubt: alter session set optimizer_mode = first_rows;
 - order-by-random to un-cluster data per parent, maximize gets on 1st qry.
 - Richard Foote has shown that unique indexes are generally better... (re-visit blog)

Finally:
 - by presenting this as demo, I make all the mistakes... 
 - confusing screen-jumps
 - reading text litteraly from screen.
 - give 2 or 3 messages at once (inflated index, enforce-constraint etc..)
 - was this detailed item worth all the hard work ?

*/

alter session set optimizer_mode = first_rows;

set echo on
set pagesize 100
set linesize 100
column table_name format A30

spool pk_overload

-- drop and recreate the table with a 2-field PK, typical parent-child.

drop table ovl;
create table ovl as 
select owner, table_name, tablespace_name, iot_type, iot_name, num_rows, avg_row_len, last_analyzed, status
from all_tables order by dbms_random.value ;
create unique index ovl_pk on ovl ( owner, table_name );
alter table ovl add constraint ovl_pk primary key ( owner, table_name ) using index ovl_pk ;

accept press_enter prompt "press enter to continue..."


-- do every qry twice to reduce effect of recursive sql at parse.
-- first pass of the qry is a good moment to use display_cursor.
-- second pass of the qry we will use autotrace-stats to see IO.

select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/
select * from table(dbms_xplan.display_cursor(null,null,'BASIC LAST'));

--
-- notice the access via PK-range, followed by idx-by-row_id
--
accept press_enter prompt "press enter to continue..."

set autotrace on stat 
select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/
set autotrace off

--
-- notice: 
-- the range-scan on PK followed by access by index-rowid.
-- the qry did many block-access to return only a few rows.
-- a full table scan might have been more efficient...?
--

accept press_enter prompt "press enter to continue..."

--
-- now we will recreate an inflated PK_index, but keep the same PK
--

alter table ovl drop constraint ovl_pk ;

drop index ovl_pk ;
create index ovl_pk on ovl ( owner, table_name, num_rows, avg_row_len);
alter table ovl add constraint ovl_pk primary key ( owner, table_name ) using index ovl_pk ;

--
-- notice the PK index is the same, only two fields, 
-- but the index contains 4 fields !
--

accept press_enter prompt "press enter to continue..."

--
-- again, do qry twice to reduce effect of recursive sql at parse.
--

select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/
select * from table(dbms_xplan.display_cursor(null,null,'BASIC LAST'));

--
-- notice: 
-- only PK-range-scan, only need to read the index
--

accept press_enter prompt "press enter to continue..."

set autotrace on stat 
select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/
set autotrace off

--
-- notice: 
-- Reduced nr of consitent-gets, no more table-access. 
-- we scanned a lot less blocks by just using the index.
-- this shows how index-only access is a beneficial.
--

accept press_enter prompt "press enter to continue..."

--
-- note: 
-- if we have to retrieve more columns, 
-- we will have to access the table.
-- 
-- But the index (with additional field) is still beneficial.
-- better filtering means less table-access....
--

accept press_enter prompt "press enter to continue..."

select table_name, avg_row_len, num_rows, status from ovl 
where owner like 'SY%' and num_rows > 100000 
/
select * from table(dbms_xplan.display_cursor(null,null,'BASIC LAST'));

--
-- notice:
-- the access is now PK + acces-by-rowid again 
--
accept press_enter prompt "press enter to continue..."

set autotrace on stat
select table_name, avg_row_len, num_rows, status from ovl 
where owner like 'SY%' and num_rows > 100000 
/
set autotrace off

--
-- but notice:
-- despite the additional acces-by-rowid, 
-- we accessed less rows then in the original qry: Filtering!
-- 

accept press_enter prompt "press enter to continue..."

-- 
-- and now select less rows in the result set
-- and see the consistent gets go down
-- 
select table_name, avg_row_len, num_rows, status from ovl 
where owner like 'SY%' and num_rows > 200000 
/
select * from table(dbms_xplan.display_cursor(null,null,'BASIC LAST'));

set autotrace on stat
select table_name, avg_row_len, num_rows, status from ovl 
where owner like 'SY%' and num_rows > 200000 
/
set autotrace off

--
-- We now selected even less rows, and 
-- the nr of gets is even lower.
-- To confirm that every access (record) to table was an additional get.
-- 

spool off
