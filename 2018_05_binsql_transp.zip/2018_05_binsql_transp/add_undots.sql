
-- add a 2nd undo tablespace, 

-- note: also generate the create-stmnt for the original undo-ts, just in case.
-- then, if undotbs1 becomes too big, alter-system and drop the first undotbs..

create undo tablespace "UNDOTBS2" 
datafile  'C:\oracle\product\10.2.0\oradata\db10\undotbs2_01.dbf' SIZE 50M REUSE 
AUTOEXTEND ON NEXT  50m MAXSIZE 500M;

-- alter system set undo_tablespace undotbs2 ;

-- you may have to wait <retention-time> minutes.
show parameter undo_retention

-- drop tablespace undotbs1; 

