
doc
	spin.sql : spin for &1 sec
#


-- select to_char ( sysdate, 'HH24:MI:SS' ) from dual;


declare 
        vc_Hi_There_I_am_Spinning  varchar2(20);

	starttime	date ;
begin
	starttime := sysdate ;

	while (sysdate - starttime) < &1 / (24 * 3600) loop
		null;
		null;
	end loop ;

end ;
/

-- select to_char ( sysdate, 'HH24:MI:SS' ) from dual;

--@sleep &1

--select to_char ( sysdate, 'HH24:MI:SS' ) from dual;

