
column nls_parm format A30 

-- drop table abc

-- create table abc as select * from dual ; 

-- cleanup.
drop table abc ;


@chk_nlslength

-- create table with default and describe
create table abc ( dummy varchar2(1) ) ; 

desc abc

accept press_enter prompt "press enter to continue..."


-- now try setting nls..
drop table abc ; 


alter session set nls_length_semantics=CHAR;

@chk_nlslength

create table abc ( dummy varchar2(1) ) ; 

desc abc

accept press_enter prompt "press enter to continue..."

-- 
create table abc ( dummy varchar2(1 char) ) ; 

desc abc

accept press_enter prompt "press enter to continue..."


-- 

set echo on
set feedb on

drop table abc;

@chk_nlslength

create table abc (
  bytecol varchar2 ( 1 byte )
, charcol varchar2 ( 1 char )
);


desc abc

set echo off
prompt .
accept press_enter prompt "showing default session..."

set echo on
alter session set nls_length_semantics=CHAR;
desc abc
set echo off

prompt .
accept press_enter prompt "showing with session set to Char..."

alter session set nls_length_semantics=byte;
desc abc
set echo off

prompt .
accept press_enter prompt "showing with session set to byte..."

set feedb on
