/*

demo of impact cluster-parameters and cluster-sizing
 - too few hash keys: oracle uses the PK to access
 - too many hash keys: wasted space (and wasted cache-size)

pre-reqs:
 - demo_clusters (to create the heap-table with 50K records)

actions:
 - re-create the cluster with a small nr hashkeys, and see how storage and qries become affected
 - re-create with sufficient hashkeys, and see the effect
 - see the effect of an OR-clause: optimizer reverts to PK
 - use a union, and optimizer goes back to hash-access.

Additionals to test for:
 - size=, 
 - monitor CPU usage in various situations.

*/

set linesize 120
set pagesize 0
set echo on

drop table   clut ;
drop cluster clu ;

-- create the cluster
create cluster clu ( key varchar2(78 byte) ) 
single table 
hashkeys 100;

CREATE TABLE clut (
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

analyze cluster clu compute statistics;
analyze table clut compute statistics;

@segsize clu

-- empty cluster. 
-- note the size with a low number of hashkeys, blocks = hashkeys.
accept pressanykey prompt "press enter..."

insert into clut select * from heap ;
commit ;

analyze cluster clu compute statistics;
analyze table clut compute statistics;

@segsize clu


-- cluster now filled with data, 
-- nr of blocks increased 
accept pressanykey prompt "press enter..."

select * from clut
where key = 'FIVE HUNDRED'
/
set autotrace on
/
set autotrace off

-- note the way the table is accessed for 1 row..
accept pressanykey prompt "press any key"

select * from clut
where key = 'FIVE HUNDRED' 
union
select * from clut
where key = 'SEVEN THOUSAND' 
/
set autotrace on
/
set autotrace off

-- note the access for multiple rows.. 
accept pressanykey prompt "press any key"


-- now test with different hashkeys and sizes...

drop table   clut ;
drop cluster clu ;

-- create the cluster
create cluster clu ( key varchar2(78 byte) ) 
single table 
hashkeys 1000;

CREATE TABLE clut (
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

analyze cluster clu compute statistics;
analyze table clut compute statistics;

@segsize clu

-- re-created with "sufficient" hashkeys, size of empty object is ... cluse to nr hashkeys
accept pressanykey prompt "press enter.. "

insert into clut select * from heap ;
commit ;

analyze cluster clu compute statistics;
analyze table clut compute statistics;

@segsize clu

-- filled with data. note avg space and empty blocks, but size did not increase 
accept pressanykey prompt "press any key"


select * from clut
where key = 'FIVE HUNDRED'
/
set autotrace on
/
set autotrace off

-- note the way the table is accessed for 1 row.. (hashkey)
accept pressanykey prompt "press any key"

select * from clut
where    key = 'FIVE HUNDRED' 
      or key = 'SEVEN THOUSAND' 
/
set autotrace on
/
set autotrace off

-- note that selecting more then 1 row, the advantage dissapears..
accept pressanykey prompt "press any key"

select * from clut
where key = 'FIVE HUNDRED' 
union
select * from clut
where key = 'SEVEN THOUSAND' 
/
set autotrace on
/
set autotrace off

-- note that a union-qry tricks the optimizer into hash-access again.
accept pressanykey prompt "press any key"
