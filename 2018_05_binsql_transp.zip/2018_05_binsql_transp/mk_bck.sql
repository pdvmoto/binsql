
rem
rem mk_bck.sql:
rem
rem purpose :
rem create sqldba-script to backup database.
rem
rem suggestions :
rem - 
rem

COLUMN  txt     FORMAT A79
COLUMN   c0     NOPRINT


SET HEADING     OFF
SET PAGESIZE    0
SET FEEDBACK    OFF

SELECT  1                               c0
,       tablespace_name                 c0
,       file_name                       c0
,       0                               c0
,       'alter tablespace '
        || tablespace_name || ' begin backup ;'  txt
FROM    dba_data_files
   UNION
SELECT  10                              c0
,       tablespace_name                 c0
,       file_name                       c0
,       0                               c0
,       'host copy ' || file_name || ' d:\orabck '  txt
FROM    dba_data_files
   UNION
SELECT  20                               c0
,       tablespace_name                 c0
,       file_name                       c0
,       0                               c0
,       'alter tablespace '
        || tablespace_name || ' end backup ;'  txt
FROM    dba_data_files
   UNION
SELECT  25                               c0
,       tablespace_name                 c0
,       file_name                       c0
,       0                               c0
,       ' '  txt
FROM    dba_data_files 
order by 2, 3, 1
/

SELECT 'alter database backup controlfile to ''d:\orabck\bck.ctl'' reuse ; '
from dual
/


 
