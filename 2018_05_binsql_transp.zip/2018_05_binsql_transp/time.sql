select to_char ( systimestamp, 'dd-mon-yyyy hh24:mi:ss.ff2' )
from dual ;

