
DROP PACKAGE SCOTT.DD_PKG;

CREATE OR REPLACE PACKAGE SCOTT.dd_pkg
as

FUNCTION create_exttab ( v_in_filename VARCHAR2 ) RETURN VARCHAR2 ;


function dd_insert_internal
return varchar2;

function dd_into_datamodel 
return varchar2;


procedure ins_n_sec ( pi_nrsec number ) ;

procedure main ( v_in_filename varchar2 ) ; 

procedure test_call ; 

end dd_pkg;
/

show errors


CREATE OR REPLACE PACKAGE BODY SCOTT.dd_pkg
as

FUNCTION create_exttab  ( v_in_filename  VARCHAR2 ) RETURN VARCHAR2
IS
  result VARCHAR2(4000) := '' ;
  stmnt  VARCHAR2(4000) := '' ;
BEGIN

  -- create-table-external...

stmnt := '
create table eomexternal
(
MessageId							varchar(40),
CreationDateTime 				date,
FileNbOfTransactions						varchar(40),
FileControlSum							varchar(40),
InitgPtyNm							varchar(40),
InitgPtyBICorBEI						varchar(40),
InitgPtyOrgId							varchar(40),
InitgPtyOrgId_SchmeNmCd						varchar(40),
InitgPtyExtrnlOrgId_Issr 					varchar(40),
MessageNm							varchar(40),
MessageVersionNb						varchar(40),
FileHash 							varchar(40),
FileStatus 							varchar(40),
PmtFileLevelInfID						varchar(40),
NbOfPmtInstructions						varchar(40),
PmtInfId							varchar(40),
PmtInstructionInf_ID 						varchar(40),
PmtMethod							varchar(40),
BatchBooking							varchar(40),
BatchNbOfTransactions						varchar(40),
BatchControlSum							varchar(40),
PmtTpServiceLevelCd						varchar(40),
PmtTpLocalInstrumentCd 						varchar(40),
PmtTpDDSqTp							varchar(40),
PmtTpCtgyPurpCd							varchar(40),
RequestedCollectionDate				date,
CdtrPtyNm							varchar(40),
CdtrCountry							varchar(40),
CdtrAddressline_1						varchar(40),
CdtrAddressline_2						varchar(40),
CdtrIBAN_Nb							varchar(40),
CdtrCashAccount_CCY						varchar(40),
CdtrAgentBIC							varchar(40),
ultCdtrPtyNm							varchar(40),
ultCdtrBICorBEI							varchar(40),
ultCdtrOrgId							varchar(40),
ultCdtrOrgId_SchmeNmCd						varchar(40),
ultCdtrExtrnlOrgId_Issr						varchar(40),
PmtInfChargebearer						varchar(40),
CdtrSchmeIdPrvtId						varchar(40),
CdtrSchmeIdPrvtId_SchmeNmCd					varchar(40),
CdtrSchmeIdPrvtId_Issr						varchar(40),
EnrchdColltnDt					date,
BatchStatus							varchar(40),
BatchHashValue							varchar(40),
InstructionId							varchar(40),
EndToEndId							varchar(40),
PmtTransactionInfID						varchar(40),
InstructedAmount						varchar(40),
InstructedAmountCurrency					varchar(40),
DrctDbtTxChargebearer						varchar(40),
MandateId							varchar(40),
DateOfSignature					date,
AmendmentIndicator					varchar(40),
OriginalMandateId						varchar(40),
OrgnlCdtrSchmeIdPrvtId				varchar(40),
OrgnlCdtrPrvtId_SchmeNmCd					varchar(40),
OrgnlCdtrPrvtId_Issr							varchar(40),
OrgnlDbtrIBAN_Nb				varchar(40),
OriginalDebtorAgtId						varchar(40),
ElectronicSignature						varchar(40),
FirstCollectionDate						varchar(40),
FinalCollectionDate							varchar(40),
Frequency						varchar(40),
TxCdtrSchmeIdPrvtId				varchar(40),
TxCdtrPrvtId_SchmeNmCd					varchar(40),
TxCdtrPrvtId_Issr							varchar(40),
UltmtCdtrPtyNm							varchar(40),
UltmtCdtrBICorBEI					varchar(40),
UltmtCdtrOrgId			varchar(40),
UltmtCdtrOrgId_SchmeNmCd				varchar(40),
UltmtCdtrOrgId_Issr							varchar(40),
DebtorAgentBIC								varchar(40),
DbtrPtyNm							varchar(40),
DbtrCountry							varchar(40),
DbtrAddressline_1							varchar(40),
DbtrAddressline_2							varchar(40),
DbtrBICorBEI					varchar(40),
DbtrOrgId			varchar(40),
DbtrOrgId_SchmeNmCd				varchar(40),
DbtrOrgId_Issr							varchar(40),
DbtrIBAN_Nb							varchar(40),
UltmtDbtrPtyNm							varchar(40),
UltmtDbtrBICorBEI					varchar(40),
UltmtDbtrOrgId			varchar(40),
UltmtDbtrOrgId_SchmeNmCd				varchar(40),
UltmtDbtrOrgId_Issr						varchar(40),
UstrdRemittanceInf				varchar(40),
CdtrRefInfCd				varchar(40),
CdtrRefInfIssr			varchar(40),
CdtrRefInfRef					varchar(40),
Status						varchar(40),
TxnHashValue						varchar(40),
StsOrgtrPrvtId_SchmeNmPrtry						varchar(40),
StatusReasonInfCd								varchar(40),
AdditionalInf1								varchar(40),
AdditionalInf2								varchar(40),
AdditionalInf3								varchar(40)
)
organization external
(default directory EXT_DATA_DIR
access parameters
(
records delimited by newline
fields terminated by ''|''
MISSING FIELD VALUES ARE NULL
(
MessageId, 
CreationDateTime date ''yyyy-mm-dd hh24:mi:ss'', 
FileNbOfTransactions, 
FileControlSum, 
InitgPtyNm,
InitgPtyBICorBEI,
InitgPtyOrgId,
InitgPtyOrgId_SchmeNmCd,
InitgPtyExtrnlOrgId_Issr,
MessageNm,
MessageVersionNb,
FileHash,
FileStatus,
PmtFileLevelInfID,
NbOfPmtInstructions,
PmtInfId,
PmtInstructionInf_ID,
PmtMethod,
BatchBooking,
BatchNbOfTransactions,
BatchControlSum,
PmtTpServiceLevelCd,
PmtTpLocalInstrumentCd,
PmtTpDDSqTp,
PmtTpCtgyPurpCd,
RequestedCollectionDate 	date ''yyyy-mm-dd hh24:mi:ss'',
CdtrPtyNm,
CdtrCountry,
CdtrAddressline_1,
CdtrAddressline_2,
CdtrIBAN_Nb,
CdtrCashAccount_CCY,
CdtrAgentBIC,
ultCdtrPtyNm,
ultCdtrBICorBEI,
ultCdtrOrgId,
ultCdtrOrgId_SchmeNmCd,
ultCdtrExtrnlOrgId_Issr,
PmtInfChargebearer,
CdtrSchmeIdPrvtId,
CdtrSchmeIdPrvtId_SchmeNmCd,
CdtrSchmeIdPrvtId_Issr,
EnrchdColltnDt 			date ''yyyy-mm-dd'',
BatchStatus,
BatchHashValue,
InstructionId,
EndToEndId,
PmtTransactionInfID,
InstructedAmount,
InstructedAmountCurrency,
DrctDbtTxChargebearer,
MandateId,
DateOfSignature 		date ''yyyy-mm-dd'',
AmendmentIndicator,
OriginalMandateId,
OrgnlCdtrSchmeIdPrvtId,
OrgnlCdtrPrvtId_SchmeNmCd,
OrgnlCdtrPrvtId_Issr,
OrgnlDbtrIBAN_Nb,
OriginalDebtorAgtId,
ElectronicSignature,
FirstCollectionDate,
FinalCollectionDate,
Frequency,
TxCdtrSchmeIdPrvtId,
TxCdtrPrvtId_SchmeNmCd,
TxCdtrPrvtId_Issr,
UltmtCdtrPtyNm,
UltmtCdtrBICorBEI,
UltmtCdtrOrgId	,
UltmtCdtrOrgId_SchmeNmCd,
UltmtCdtrOrgId_Issr,
DebtorAgentBIC,
DbtrPtyNm,
DbtrCountry,
DbtrAddressline_1,
DbtrAddressline_2,
DbtrBICorBEI,
DbtrOrgId,
DbtrOrgId_SchmeNmCd,
DbtrOrgId_Issr,
DbtrIBAN_Nb,
UltmtDbtrPtyNm,
UltmtDbtrBICorBEI,
UltmtDbtrOrgId,
UltmtDbtrOrgId_SchmeNmCd,
UltmtDbtrOrgId_Issr,
UstrdRemittanceInf,
CdtrRefInfCd,
CdtrRefInfIssr,
CdtrRefInfRef,
Status,
TxnHashValue,
StsOrgtrPrvtId_SchmeNmPrtry,
StatusReasonInfCd,
AdditionalInf1,
AdditionalInf2,
AdditionalInf3
)
)
location ('':1'')
)
' ;

execute immediate stmnt using v_in_filename ;

-- alternative: dont use the :1 and dont specify the using filename clause. 
-- location (''csv.out'')
-- execute immediate stmnt;


  result := '' ;
  RETURN result;

end create_exttab ;


function dd_insert_internal 
return varchar2
IS
  vc_result VARCHAR2(4000);
--  vc_msg_id varchar2(64);
--  vc_md5    varchar2(64) := ' ';

BEGIN

  -- insert stmnt from external table to internal table.

insert into eominternal
(eominternal_pk,
MessageId,
CreationDateTime,
FileNbOfTransactions,
FileControlSum,
InitgPtyNm,
InitgPtyBICorBEI,
InitgPtyOrgId,
InitgPtyOrgId_SchmeNmCd,
InitgPtyExtrnlOrgId_Issr,
MessageNm,
MessageVersionNb,
FileHash,
FileStatus,
PmtFileLevelInfID,
NbOfPmtInstructions,
PmtInfId,
PmtInstructionInf_ID,
PmtMethod,
BatchBooking,
BatchNbOfTransactions,
BatchControlSum,
PmtTpServiceLevelCd,
PmtTpLocalInstrumentCd,
PmtTpDDSqTp,
PmtTpCtgyPurpCd,
RequestedCollectionDate,
CdtrPtyNm,
CdtrCountry,
CdtrAddressline_1,
CdtrAddressline_2,
CdtrIBAN_Nb,
CdtrCashAccount_CCY,
CdtrAgentBIC,
ultCdtrPtyNm,
ultCdtrBICorBEI,
ultCdtrOrgId,
ultCdtrOrgId_SchmeNmCd,
ultCdtrExtrnlOrgId_Issr,
PmtInfChargebearer,
CdtrSchmeIdPrvtId,
CdtrSchmeIdPrvtId_SchmeNmCd,
CdtrSchmeIdPrvtId_Issr,
EnrchdColltnDt,
BatchStatus,
BatchHashValue,
InstructionId,
EndToEndId,
PmtTransactionInfID,
InstructedAmount,
InstructedAmountCurrency,
DrctDbtTxChargebearer,
MandateId,
DateOfSignature,
AmendmentIndicator,
OriginalMandateId,
OrgnlCdtrSchmeIdPrvtId,
OrgnlCdtrPrvtId_SchmeNmCd,
OrgnlCdtrPrvtId_Issr,
OrgnlDbtrIBAN_Nb,
OriginalDebtorAgtId,
ElectronicSignature,
FirstCollectionDate,
FinalCollectionDate,
Frequency,
TxCdtrSchmeIdPrvtId,
TxCdtrPrvtId_SchmeNmCd,
TxCdtrPrvtId_Issr,
UltmtCdtrPtyNm,
UltmtCdtrBICorBEI,
UltmtCdtrOrgId,
UltmtCdtrOrgId_SchmeNmCd,
UltmtCdtrOrgId_Issr,
DebtorAgentBIC,
DbtrPtyNm,
DbtrCountry,
DbtrAddressline_1,
DbtrAddressline_2,
DbtrBICorBEI,
DbtrOrgId,
DbtrOrgId_SchmeNmCd,
DbtrOrgId_Issr,
DbtrIBAN_Nb,
UltmtDbtrPtyNm,
UltmtDbtrBICorBEI,
UltmtDbtrOrgId,
UltmtDbtrOrgId_SchmeNmCd,
UltmtDbtrOrgId_Issr,
UstrdRemittanceInf,
CdtrRefInfCd,
CdtrRefInfIssr,
CdtrRefInfRef,
Status,
TxnHashValue,
StsOrgtrPrvtId_SchmeNmPrtry,
StatusReasonInfCd,
AdditionalInf1,
AdditionalInf2,
AdditionalInf3)
--------------------------------------------------------------------------------------------------------------------
select eominternal_pk.nextval,
MessageId,
CreationDateTime,
FileNbOfTransactions,
FileControlSum,
InitgPtyNm,
InitgPtyBICorBEI,
InitgPtyOrgId,
InitgPtyOrgId_SchmeNmCd,
InitgPtyExtrnlOrgId_Issr,
MessageNm,
MessageVersionNb,
FileHash,
FileStatus,
PmtFileLevelInfID,
NbOfPmtInstructions,
PmtInfId,
PmtInstructionInf_ID,
PmtMethod,
BatchBooking,
BatchNbOfTransactions,
BatchControlSum,
PmtTpServiceLevelCd,
PmtTpLocalInstrumentCd,
PmtTpDDSqTp,
PmtTpCtgyPurpCd,
RequestedCollectionDate,
CdtrPtyNm,
CdtrCountry,
CdtrAddressline_1,
CdtrAddressline_2,
CdtrIBAN_Nb,
CdtrCashAccount_CCY,
CdtrAgentBIC,
ultCdtrPtyNm,
ultCdtrBICorBEI,
ultCdtrOrgId,
ultCdtrOrgId_SchmeNmCd,
ultCdtrExtrnlOrgId_Issr,
PmtInfChargebearer,
CdtrSchmeIdPrvtId,
CdtrSchmeIdPrvtId_SchmeNmCd,
CdtrSchmeIdPrvtId_Issr,
EnrchdColltnDt,
BatchStatus,
BatchHashValue,
InstructionId,
EndToEndId,
PmtTransactionInfID,
InstructedAmount,
InstructedAmountCurrency,
DrctDbtTxChargebearer,
MandateId,
DateOfSignature,
AmendmentIndicator,
OriginalMandateId,
OrgnlCdtrSchmeIdPrvtId,
OrgnlCdtrPrvtId_SchmeNmCd,
OrgnlCdtrPrvtId_Issr,
OrgnlDbtrIBAN_Nb,
OriginalDebtorAgtId,
ElectronicSignature,
FirstCollectionDate,
FinalCollectionDate,
Frequency,
TxCdtrSchmeIdPrvtId,
TxCdtrPrvtId_SchmeNmCd,
TxCdtrPrvtId_Issr,
UltmtCdtrPtyNm,
UltmtCdtrBICorBEI,
UltmtCdtrOrgId,
UltmtCdtrOrgId_SchmeNmCd,
UltmtCdtrOrgId_Issr,
DebtorAgentBIC,
DbtrPtyNm,
DbtrCountry,
DbtrAddressline_1,
DbtrAddressline_2,
DbtrBICorBEI,
DbtrOrgId,
DbtrOrgId_SchmeNmCd,
DbtrOrgId_Issr,
DbtrIBAN_Nb,
UltmtDbtrPtyNm,
UltmtDbtrBICorBEI,
UltmtDbtrOrgId,
UltmtDbtrOrgId_SchmeNmCd,
UltmtDbtrOrgId_Issr,
UstrdRemittanceInf,
CdtrRefInfCd,
CdtrRefInfIssr,
CdtrRefInfRef,
Status,
TxnHashValue,
StsOrgtrPrvtId_SchmeNmPrtry,
StatusReasonInfCd,
AdditionalInf1,
AdditionalInf2,
AdditionalInf3
from eomexternal ;


  RETURN vc_result;
END dd_insert_internal ;


function dd_into_datamodel 
return varchar2
IS
  vc_result VARCHAR2(4000);
  msg_id varchar(64);
--  vc_msg_id varchar2(64);
--  vc_md5    varchar2(64) := ' ';
BEGIN

  vc_result := '' ;

  -- number of ins-sttmnts from internal-table into datamodel-tables.

--insert all
--insert
--into PMTFLLVLINF
--( MSGID, CREDTTM, FLNM, CTRLSUM, MSSGNM, MSSGVRSNNMBR, FILEHSH, FILESSTST, PMTFLLVLID,NBOFPMTINSTR )
--select MessageId, CREATIONDATETIME, FileNbOfTransactions, FileControlSum, MessageNm, MessageVersionNb,
--FileHash, FileStatus, PmtFileLevelInfID, NbOfPmtInstructions
--from eominternal
--/

insert
into PMTFLLVLINF
( PMTFLLVLID, MSGID, CREDTTM, FLNM, CTRLSUM, MSSGNM, MSSGVRSNNMBR, FILEHSH, FILESSTST, NBOFPMTINSTR )
select PMTFLLVLINF_seq.nextval, MessageId, CREATIONDATETIME, FileNbOfTransactions, FileControlSum, MessageNm, MessageVersionNb,
FileHash, FileStatus, NbOfPmtInstructions
from eominternal;

--insert
--into INTRNLPRTYID
--(PRTID, PMTFLLVLID, PRTNM, PRTBICORBEI, ORGID, ORGIDSCHMENMCD,ORGIDISSR, PRTCTRY, PRTADRLINE_1, PRTADRLINE_2)
--select INTRNLPRTYID_seq.nextval, InitgPtyNm, INITGPTYBICORBEI, INITGPTYORGID, INITGPTYORGID_SCHMENMCD, INITGPTYEXTRNLORGID_ISSR,
--CdtrCountry, CdtrAddressline_1, CdtrAddressline_2
--from eominternal
--/

insert
into INTRNLPRTYID
(PRTID, PRTNM, PRTBICORBEI, ORGID, ORGIDSCHMENMCD,ORGIDISSR, PRTCTRY, PRTADRLINE_1, PRTADRLINE_2)
select INTRNLPRTYID_seq.nextval, InitgPtyNm, INITGPTYBICORBEI, INITGPTYORGID, INITGPTYORGID_SCHMENMCD, INITGPTYEXTRNLORGID_ISSR,
CdtrCountry, CdtrAddressline_1, CdtrAddressline_2
from eominternal;

insert
into INTRNLPRTYID
(PRTID, PRTNM, PRTBICORBEI, ORGID, ORGIDSCHMENMCD,ORGIDISSR, PRTCTRY, PRTADRLINE_1, PRTADRLINE_2, PRVTIDSCHMENMPRTRY)
select INTRNLPRTYID_seq.nextval, CdtrPtyNm, INITGPTYBICORBEI, INITGPTYORGID, INITGPTYORGID_SCHMENMCD, INITGPTYEXTRNLORGID_ISSR,
CdtrCountry, CdtrAddressline_1, CdtrAddressline_2, StsOrgtrPrvtId_SchmeNmPrtry
from eominternal;

insert 
into DDPMTINSTRINF
( PMTINFID,  PMTINSTRINFID, PMTMTD, BTCHBOOKG, NBOFTX, CTRLSUM, PMTTPSVCLVLCD, PMTTPLCLINSTRMCD, PMTTPDDSEQTP, 
PMTTPCTGYPURPCD, REQDCOLLNDT, CDTRAGTBIC, CHRGBR, ENRCHDCOLLNDT, BTCHSTS, BTCHHSHVAL )
select PmtInfId, PmtInstructionInf_ID, PmtMethod, BatchBooking, BatchNbOfTransactions, BatchControlSum, 
PMTTPSERVICELEVELCD,PMTTPLOCALINSTRUMENTCD, PMTTPDDSQTP, PMTTPCTGYPURPCD, RequestedCollectionDate, CdtrAgentBIC,
PmtInfChargebearer, EnrchdColltnDt, BatchStatus, BatchHashValue 
from eominternal ;

insert 
into CSHACCT
(CSHACCTID, IBAN, CSHACCTCCY)
select CSHACCT_SEQ.nextval, CdtrIBAN_Nb, CdtrCashAccount_CCY
from eominternal;

insert 
into CSHACCT
(CSHACCTID,IBAN)
select CSHACCT_SEQ.nextval, DbtrIBAN_Nb
from eomexternal ;

insert 
into EXTRNLLPRTYID
(PRTID, PRTNM, PRTBICORBEI, ORGID, ORGIDSCHMENMCD, ORGIDISSR, PRVTID, PRVTIDSCHMENMCD, PRVTIDISSR)
select EXTRNLLPRTYID_seq.nextval, UltCdtrPtyNm, UltCdtrBICorBEI, UltCdtrOrgId, UltCdtrOrgId_SchmeNmCd, UltCdtrExtrnlOrgId_Issr,
OrgnlCdtrSchmeIdPrvtId, OrgnlCdtrPrvtId_SchmeNmCd, OrgnlCdtrPrvtId_Issr 
from eominternal ;

insert 
into EXTRNLLPRTYID
(PRTID, PRTNM, PRTBICORBEI, ORGID, ORGIDSCHMENMCD, ORGIDISSR, PRVTID, PRVTIDSCHMENMCD, PRVTIDISSR )
select EXTRNLLPRTYID_seq.nextval, UltmtCdtrPtyNm, UltmtCdtrBICorBEI, UltmtCdtrOrgId, UltmtCdtrOrgId_SchmeNmCd, UltmtCdtrOrgId_Issr,
TxCdtrSchmeIdPrvtId, TxCdtrPrvtId_SchmeNmCd, TxCdtrPrvtId_Issr
from eominternal;

insert 
into EXTRNLLPRTYID
(  PRTID, PRTNM, PRTCTRY, PRTADRLINE_1, PRTADRLINE_2, PRTBICORBEI, ORGID, ORGIDSCHMENMCD, ORGIDISSR)
select EXTRNLLPRTYID_seq.nextval,DbtrPtyNm, DbtrCountry, DbtrAddressline_1, DbtrAddressline_2, DbtrBICorBEI, DbtrOrgId, DbtrOrgId_SchmeNmCd, DbtrOrgId_Issr
from eominternal;

insert
into EXTRNLLPRTYID
(PRTNM, PRTBICORBEI, ORGID, ORGIDSCHMENMCD, ORGIDISSR)
select UltmtDbtrPtyNm, UltmtDbtrBICorBEI, UltmtDbtrOrgId, UltmtDbtrOrgId_SchmeNmCd, UltmtDbtrOrgId_Issr
from eominternal;

--insert
--into DDTRXINF
--(PMTTXINFID, ENDTOENDID,  INSTDAMT, INSTDAMTCCY, CHRGBR, DBTRAGTBIC, STST, TXNHSCHVAL )
--select DDTRXINF_seq.nextval, EndToEndId, PmtTransactionInfID, InstructedAmount, InstructedAmountCurrency,
--DrctDbtTxChargebearer, DebtorAgentBIC, Status, TxnHashValue
--from eominternal
--/

insert
into DDTRXINF
(PMTTXINFID, ENDTOENDID,  INSTDAMT, INSTDAMTCCY, CHRGBR, DBTRAGTBIC, STST, TXNHSCHVAL )
select DDTRXINF_seq.nextval, EndToEndId, InstructedAmount, InstructedAmountCurrency,
DrctDbtTxChargebearer, DebtorAgentBIC, Status, TxnHashValue
from eominternal ;

insert
into DDTRXINF
(PMTTXINFID, STST, TXNHSCHVAL )
select DDTRXINF_seq.nextval, Status, TxnHashValue
from eominternal ;

insert 
into DDMNDTRLTINF
( PMTTXINFID, MNDTID, DTOFSGNTR, AMDMNTIND)
select DDMNDTRLTINF_seq.nextval, MANDATEID, DATEOFSIGNATURE, AMENDMENTINDICATOR
from eominternal;
 
insert
into DDMNDTAMDMNTINFDTLS
( PMTTXINFID, ORGNLMNDTID, ORGNLDBTR )
select DDMNDTAMDMNTINFDTLS_seq.nextval, ORIGINALMANDATEID, ORIGINALDEBTORAGTID
from eominternal ;

insert 
into DDUSTRDRMTINF
(UNSTRDRMTINFID, UNSTRDRMTINF )
select DDUSTRDRMTINF_seq.nextval, UstrdRemittanceInf
from eominternal;

insert
into DDSTRDRMTINF
( STRDRMTINFID, CDTRREFINFCD, CDTRREFINFISSR, CDTRREFINFREF)
select DDSTRDRMTINF_seq.nextval, CdtrRefInfCd, CdtrRefInfIssr, CdtrRefInfRef
from eominternal;

insert
into DDPMTTRXSTSRSNINF
( PMTTRXSTSRSNINFID, STSRSNINFCD, ADDTLINF1, ADDTLINF2, ADDTLINF3 )
select DDPMTTRXSTSRSNINF_seq.nextval, StatusReasonInfCd, AdditionalInf1, AdditionalInf1, AdditionalInf1
from eominternal;


--into int_empf2
--(empno, name, deptno)
--values (empno, name, deptno)
--into int_empf3
--(empno, manager, deptno)
--values (empno, manager, deptno)
--select empno, name, job, manager, sal, deptno
--from int_emp
--where loaded is NULL
--/
--update int_emp
--set loaded='Y'
--where loaded is null
--/
--commit
--/



  EXCEPTION
  WHEN no_data_found THEN
    vc_result := 'No Data Found for msg_id [' || msg_id || ']' ;
    dbms_output.put_line ( vc_result ) ;
  WHEN OTHERS THEN
	null ;
	-- raise ;

  RETURN vc_result;
END dd_into_datamodel ;



-- -- -- further procedures are the test-frame

PROCEDURE ins_n_sec ( pi_nrsec number )
as
  starttime	date ;
  vc_result        varchar2(64) ;
  vc_sid        varchar2( 5) ;
  vc_key	varchar2(32) ;
  n_counter	number := 0 ;
  n_dups	number := 0 ;

begin

  vc_sid := translate ( to_char ( to_number ( userenv ('SID' ) ), 'XXX' ), ' ', '0' ) ;  -- need a hex string.

  starttime := sysdate ;

  while (sysdate - starttime) < pi_nrsec / (24 * 3600) loop

    n_counter := n_counter + 1;
    vc_key    := to_char (  to_number ( to_char ( systimestamp, 'FF3DDDHH24MISSFF4'   ) )
                          + mod ( n_counter, 1000 )
                       /* , 'XXXXXXXXXXXX' */
                         ) || vc_sid ;

    -- dbms_output.put_line ( 'ins-val : [' || vc_key || ']') ;


    -- consider checking + logging duplicate-errors.
    if vc_result = 'OK' Then
      commit ; --write  wait ;  -- consider "commit write wait;"
    else
      n_dups := n_dups + 1 ;
    end if ;

  end loop ;

  dbms_output.put_line ( 'ins_n_sec : '|| to_char ( pi_nrsec) || ' sec, ' || to_char (n_counter) || ' loops, ' || n_dups || ' dups, ' || to_char (  (n_counter - n_dups ) / pi_nrsec)  || ' ins/sec.' );

end ;


PROCEDURE main ( v_in_filename varchar2 )
as
  starttime	date ;
  vc_result        varchar2(64) ;
  vc_sid        varchar2( 5) ;
  vc_key	varchar2(32) ;
  n_counter	number := 0 ;
  n_dups	number := 0 ;

begin

  dbms_output.put_line ( 'main : start.' );

  starttime := sysdate ;

  vc_result := create_exttab ( 'csv.out' );
 
  vc_result := dd_insert_internal ;

  vc_result := dd_into_datamodel ;


  -- and further calls..

  dbms_output.put_line ( 'main : end.' );

end ;

-- and a main-proc without filename
PROCEDURE main 
as
  starttime	date ;
  vc_result        varchar2(64) ;

begin

  dbms_output.put_line ( 'test call : start.' );

  null;

  dbms_output.put_line ( 'test_call : end.' );

end ;

end dd_pkg;
/


show errors

