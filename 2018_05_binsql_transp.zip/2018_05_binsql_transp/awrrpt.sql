rem
rem awrrpt.sql; placeholder for awr report...
rem

@?/rdbms/admin/awrrpt

