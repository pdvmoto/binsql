
column tablespace_name format A20 
column size_gb         format 999,999
column max_gb          format 999,999
column cangrow_gb      format 999,999

select tablespace_name
, round ( bytes /(1024*1024*1024)) size_gb 
, round ( maxbytes /(1024*1024*1024) ) max_gb
, round ( ( maxbytes - bytes)/(1024*1024*1024) ) cangrow_gb
from dba_data_files  
order by tablespace_name, file_name ; 
