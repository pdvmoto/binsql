
-- get data from a given SID or terminal (in epplus-speak, terminal = SID)
-- try listing current and last sql with plan

column sqlhash new_value curr_sql
column prev_hash_value new_value prev_sql

set linesize 200 

select s.osuser as osuser
, s.username orauser
, s.sid, s.serial# 
, s.sql_hash_value sqlhash
, s.prev_hash_value 
, p.terminal
, s.program
, s.module, s.client_info
--, p.*,  s.* 
from v$session s
, v$process p
where p.addr = s.paddr
and s.sid = &1
/

@expl_hash &curr_sql

@expl_hash &prev_sql
