
set echo on

select count (*) from dba_objects;

select count (*) from dba_synonyms;

select count (*) from dba_tab_columns;




