doc
    scan06.sql

    Top-15 for CPU-, IO- and SQL*Net usages per session.
   
    Note for CPU usage you should have set timed_statistics=TRUE, 
    otherwise you only see zero's.

#

clear columns
set serveroutput on
set feedback off
column value format 999999999
declare 
	-- cpu 
    cursor c1 is
    select    rpad ( substr  ( NVL  ( ss.username, 'Bckgrnd' ), 1, 12 ), 12 )
    || ' ' || lpad ( to_char ( ss.sid, '999' ), 		 4 )
    || ' ' || nvl  ( substr  ( lpad ( ss.program, 30 ),  -28 ), '                            ')
    || ' ' || lpad ( to_char ( st.value/100, '999999.99' ), 10 ) 
    || ' ' || lpad ( substr  ( NVL  (ss.osuser, 'SYS' ),1,6) , 6)
    || '@' || rpad ( substr  ( NVL  (ss.machine, vd.name) ,1, 14 ), 14)
    from                v$sesstat                               st
    ,                   v$session                               ss
    ,                   v$database                              vd
    where               st.sid = ss.sid
    and                 st.statistic# = 12 -- CPU used by this session in V734, V80 and V815
    order by            st.value desc ;
	
	-- io per session
	  cursor c2 is
	  select	rpad ( substr ( nvl ( ss.username, 'Bckgrnd' ), 1, 12 ), 12 )
    || ' ' ||	lpad ( to_char ( ss.sid, '999' ),   4 )
    || ' ' ||   lpad ( to_char ( sr.value,              '99999999999'  ),  12 )    -- reads
    || ' ' ||	lpad ( to_char ( sw.value,              '99999999999'  ),  12 )    -- writes
    || ' ' ||	lpad ( to_char ( (sw.value + sr.value),	'999999999999' ),  13 )    -- total
    || ' ' ||   lpad (substr(NVL(ss.osuser, 'SYS' ),1,6) , 6)
    || '@' ||   rpad( substr( NVL ( ss.machine, vd.name) ,1, 14 ), 14)
    from                v$sesstat                               sr
    ,                   v$sesstat                               sw
    ,                   v$session                               ss
    ,                   v$sysstat                               sy1
    ,                   v$sysstat                               sy2
    ,                   v$database                              vd
    where               1=1
    and			sr.sid = ss.sid
    and			sw.sid = ss.sid
    and                 sr.statistic# = sy1.statistic#
    and                 sy1.name = 'physical reads'
    and                 sw.statistic# = sy2.statistic#
    and                 sy2.name = 'physical writes'
    order by      	nvl ( sw.value + sr.value, -1 ) desc ;

	-- sql*net traffic  per session
	  cursor c3 is
	  select /*+RULE */  rpad ( substr ( nvl ( ss.username, 'Bckgrnd' ), 1, 12 ), 12 )
    || ' ' || lpad ( to_char ( ss.sid, '999' ),     4 )
    || ' ' || lpad ( to_char ( st.value,                    '999999999' ), 10 ) -- trips
    || ' ' || lpad ( to_char ( sr.value / 1024,             '9999999' ), 8 )    -- sent
    || ' ' || lpad ( to_char ( sw.value / 1024,             '9999999' ), 8 )    -- recvd
    || ' ' || lpad ( to_char( (sw.value + sr.value) / 1024, '999999999' ), 10 ) -- total
    || ' ' || lpad (substr(NVL(ss.osuser, 'SYS' ),1,6) , 6)
    || '@' || rpad( substr( NVL (ss.machine, vd.name) ,1, 14 ), 14)
    from                v$sesstat                               sr
    ,                   v$sesstat                               sw
    ,                   v$sesstat                               st
    ,                   v$session                               ss
    ,                   v$sysstat                               sy1
    ,                   v$sysstat                               sy2
    ,                   v$sysstat                               sy3
    ,                   v$database                              vd
    where               1=1
    and     sr.sid = ss.sid
    and     sw.sid = ss.sid
    and     st.sid = ss.sid
    and                 sr.statistic# = sy1.statistic#
    and                 sy1.name = 'bytes sent via SQL*Net to client'
    and                 sw.statistic# = sy2.statistic#
    and                 sy2.name = 'bytes received via SQL*Net from client'
    and                 st.statistic# = sy3.statistic#
    and                 sy3.name = 'SQL*Net roundtrips to/from client'
    order by            (sr.value + sw.value) desc;
    
    n_numrows		number  := 16;
    vc2_text		varchar2 (80) ;
	
begin

	dbms_output.enable( 20000 );
	
	-- heading, max 80!
	dbms_output.put_line ( '.' );
	dbms_output.put_line ( 
	'CPU usage per session in seconds: ' );
	dbms_output.put_line ( 
	'username       sid        program                     cpu      osuser @ machine' );
	dbms_output.put_line ( 
	'-------------------------------------------------------------------------------' );
	
	open c1;
	fetch c1 into vc2_text ;	
	while 	(		(c1%found					)
		 	and 	(c1%rowcount <  n_numrows 	) ) 
	loop
		dbms_output.put_line ( vc2_text );
		fetch c1 into vc2_text ;
	end loop ;
	close c1;
	
	dbms_output.put_line ( '. ' );
	
	-- now top-10 io per session
	
	-- heading, max 80!
	dbms_output.put_line ( '. ' );
	dbms_output.put_line ( 
	'Physical IO usage per session (Ordered by total blocks read and writen): ' );	
	dbms_output.put_line ( 
	'username       sid       reads       writes         total      osuser @ machine' );
	dbms_output.put_line (	
	'-------------------------------------------------------------------------------' );
	
	open c2;
	fetch c2 into vc2_text ;	
	while 	(		(c2%found					)
		 	and 	(c2%rowcount <  n_numrows 	)
		 	) 
	loop
		dbms_output.put_line ( vc2_text );
		fetch c2 into vc2_text ;
	end loop ;

	close c2;
	dbms_output.put_line ( '. ' );
	
	-- sqlnet traffic
	dbms_output.put_line ( '. ' );
	dbms_output.put_line (
	'SQL*Net usage per session (ordered by total sent and recevied Kbytes): ' );	
	dbms_output.put_line ( 
	'username      sid roundtrips     sent   received    total        osuser@machine' );
	dbms_output.put_line (	
	'---------------------------------[Kb]-----[Kb]------[ Kb]----------------------' );
	
	open c3;
	fetch c3 into vc2_text ;	
	while 	(		(c3%found					)
		 	and 	(c3%rowcount <  n_numrows 	)
		 	) 
	loop
		dbms_output.put_line ( vc2_text );
		fetch c3 into vc2_text ;
	end loop ;

	close c3;
	dbms_output.put_line ( '. ' );	
	
end;
/

set feedback on
clear columns
prompt
