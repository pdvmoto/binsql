/*

The spooling of txt-report from AWR

There are two related files, dependent on one-another:
1. awr_last.sql     : spool a text report of the last valid interval.
2. awr_manual_s1_s2 : spool report with &1 and &2 as begin/end snapshots.

notes:

1. We find the last snapshot from max-begin-inteval:
SELECT * FROM sys.wrm$_snapshot
WHERE begin_interval_time = ( SELECT MAX (begin_interval_time) FROM sys.wrm$_snapshot)
1.1: caveat: the last two snapshots should form a valid combination, e.g. ahve same startup-time
(used to have qry for that)

2. from awrrpti.sql, we found all the relevant define-stmnts.

3. Note: this only spools the LAST interval !
	if we want to spool manually certain intervals, we need another script:
	call awr_manual.sql : with begin/end snapshots are &1 and &1
	
*/

-- some values do not need setting:
      define  inst_name    = 'Instance';
      define  db_name      = 'Database';
      define  report_type  = 'html';
      define  num_days     = 1;

-- some values need setting, as they can differ from one run to aother,
-- we will assume we need a txt report over the last valid interval,
-- hence we look for the last two snaps, the inst_id, the dbid.#
-- the report name will be constructed separately, from time-

column dinst_num    format A55
column ddbid        format A55
column dbegin_snap  format A55
column dend_snap    format A55
column dreport_name format A55

set linesize 60
set heading off
set feedb off
set verify off

spool last_awrrpt.lst

--0....,....1....,....2....,....3....,....4
SELECT '@awr_manual_s1_s2 ' || (s1.snap_id - 3) || ' ' || (s2.snap_id - 3) AS dend_snap
FROM 
dba_hist_snapshot s1, /* sys.wrm$_snapshot s1,  */
dba_hist_snapshot s2  /* sys.wrm$_snapshot s2   */
WHERE s1.dbid                 = s2.dbid
  AND s1.instance_number      = s2.instance_number
  AND s1.startup_time         = s2.startup_time
  AND s1.end_interval_time    = s2.begin_interval_time
  AND  s2.begin_interval_time = 
          ( SELECT MAX (begin_interval_time) FROM /* sys.wrm$_snapshot*/ dba_hist_snapshot) -- is s2 the latest ?  
ORDER BY s1.snap_id DESC;

spool off

-- now call the script to add the other definitions, 
-- this will then use awr_manual_s1_s2.sql to run the actual report.
@last_awrrpt.lst
