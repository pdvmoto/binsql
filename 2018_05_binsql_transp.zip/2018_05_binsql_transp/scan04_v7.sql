doc
	scan04_v7.sql
	Transaction volume for last 50 log switches. 
        (If available in v$log_history)
	- less then 900 seconds per switch is "fast",
		consider larger logfiles
	- Last column > 100.0 is considered "high volume"
		examine batches, try to spread (batch) load over time
#

column switch           format a24
column sec		format 9999
column ch_per_sec	format 9999.999
column kb_per_sec	format 9999.9
set heading on
set feedback on
set pagesize 120
select 	to_char(to_date(lh2.time, 'MM/DD/RR HH24:MI:SS'), 'MM/DD/RRRR HH24:MI:SS') switch
,       to_number (to_date ( lh2.time, 'MM/DD/YY HH24:MI:SS' ) 
	- 	to_date ( lh1.time, 'MM/DD/YY HH24:MI:SS' )  ) * 3600 * 24 		seconds 
,      ( l.bytes / 1024  ) / ( to_number ( TO_DATE ( lh2.time, 'MM/DD/YY HH24:MI:SS' ) 
	- 	to_date ( lh1.time, 'MM/DD/YY HH24:MI:SS' )  ) * 3600 * 24)		kb_per_sec 
from 	v$log_history lh1
, 		v$log_history lh2
,		v$log		l
where lh1.sequence# = lh2.sequence# -1
and     to_number (     to_date ( lh2.time, 'MM/DD/YY HH24:MI:SS' ) 
					-   to_date ( lh1.time, 'MM/DD/YY HH24:MI:SS' )
					) * 3600 * 24  > 0     /* min. 60 avoids hot bck peaks */
and 	l.status = 'CURRENT' 		/* assume  all groups equal file-sizes */
and lh1.sequence# > l.sequence# - 52
order by lh1.sequence# 
/

set pagesize 14
clear columns
prompt
