
-- test access to STHC on index-range...
-- run after demo_sthc_moredata

select count(*) nr_recs, sum( num_key) total from clut
where key between 'FIVE HUNDRED' and 'FIVE HUNDREDc'
/
set autotrace on
/
set autotrace off



select count(*) nr_recs, sum( num_key) total from clut
where key between 'FIVE HUNDRED' and 'FIVE HUNDREDc'
and padding like '1%'
/
set autotrace on
/
set autotrace off

