set linesize 100 
set pagesize 100 

drop table smalltbl;

--  very small table, just one row.
create table smalltbl as select dummy, 'more' as more from dual ;

-- a unique index, to prevent 2nd-visit to index to check for for "more rows"
create unique index smalltbl_pk on smalltbl ( dummy ) ;

select * from smalltbl where dummy = 'X'
/
set autotrace on
/
set autotrace off

analyze table smalltbl compute statistics ;

select * from smalltbl where dummy = 'X'
/
set autotrace on
/
set autotrace off


