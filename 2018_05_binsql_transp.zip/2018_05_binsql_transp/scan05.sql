rem following fires correct platform dependend version of the script io.sql
set heading off
set feedback off

spool scan05_os.lst

select decode ( decode (sign (instr(F.file_name,'/',-1) ), 1, 3, 0)
                +      
                decode (sign (instr(F.file_name,'\',-1) ), 1, 2, 0)
                , 3 , '@scan05_lunix.sql'
                , 2 , '@scan05_windows.sql'
                    , '@scan_os.sql' )
from   sys.dba_data_files F
where  rownum < 2 
/

spool off

@scan05_os.lst

set heading on
set feedback on
