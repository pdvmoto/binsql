
-- we know that on average, our records are approx 75 bytes...
-- lets tell the system when we create the cluster:

drop table clut ;
drop cluster clu ;

set echo on

CREATE CLUSTER clu ( key varchar2(78 byte) ) 
  SINGLE TABLE 
    SIZE 75
HASHKEYS 65536;

CREATE TABLE clut (
  key            VARCHAR2(78 BYTE),
  num_key        NUMBER,
  date_modified  DATE,
  padding        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

set echo off

select segment_name, bytes / (1024 ) as KB, blocks
from user_segments where segment_name like 'CLU%';

prompt NOTE: 
prompt With SIZE and expected nr of HASHKEYS specified, 
prompt the cluster is created with similar size as 
prompt the heap table that contains the same data.
Prompt
prompt Nb: The index to enforce the PK is created with default storage.
prompt
pause Have a look at the sizes and press enter to start inserting data ...

set echo on
insert into clut select * from heap ;
commit ;

analyze table clut compute statistics ;
set echo off

select segment_name, bytes / (1024) as KB, blocks
from user_segments where segment_name like 'CLU%';

prompt NOTE: 
prompt Once the data is inserted, the cluster has grown...  
prompt and the PK has of course also grown. 
prompt
pause Have a look at the sizes and press enter to continue ..

