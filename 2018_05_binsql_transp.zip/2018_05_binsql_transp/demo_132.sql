
/*

drop table t132;

create table t132 (
 id number
, name varchar2(32)
);

alter table t132 add ( constraint t132_pk primary key  ( id ) ) ;

insert into t132
select rownum, object_name 
from all_objects
where rownum <= 10;

commit ;

*/

set autotrace explain

-- show two different plans, with/out stats..

analyze table t132 delete statistics ;

set linesize 132
set autotrace on explain

select id, name from t132 
where id < 10 
order by name;

analyze table t132 compute statistics ;

select id, name from t132 
where id < 10
order by name ;

set autotrace off

-- now trace both cases to obtain hints..

analyze table t132 delete statistics ;

@set_10132

select id, name from t132 
where id < 10 
order by name;

analyze table t132 compute statistics ;

select id, name from t132 
where id < 10
order by name ;

-- stop the trace..

-- now would the hint do the full-scan ??
--  noooo ??
set autotrace on expl

select id, name from t132 
where id < 10
order by name ;

select 
  /*+
    BEGIN_OUTLINE_DATA
      IGNORE_OPTIM_EMBEDDED_HINTS
      OPTIMIZER_FEATURES_ENABLE('10.2.0.3')
      ALL_ROWS
      OUTLINE_LEAF(@"SEL$F5BB74E1")
      MERGE(@"SEL$2")
      OUTLINE(@"SEL$1")
      OUTLINE(@"SEL$2")
      FULL(@"SEL$F5BB74E1" "T132"@"SEL$2")
    END_OUTLINE_DATA
  */
  id, name from t132 
where id < 10 
order by name;

disconnect 
