rem
rem awrrpt.sql; placeholder for awr report...
rem

-- info about SYSAUX and AWR
-- need to be sys of have qry priv on sys tables
-- @?/rdbms/admin/awrinfo

-- usefull for comparing two periods.
--@?/rdbms/admin/awrddrpt

-- for a single SQL_ID, in a given period.
@?/rdbms/admin/awrsqrpt


