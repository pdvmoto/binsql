

column endtime    format A15 
column event_name format A25 

column lfsyn_tot     format 999,999.99
column lfsyn_avg     format   9,999.9

column lfsyn_tot    format 999,999.99
column lfsyn_avg    format   9,999.9

/*
 a version based directly on the wrm/wrh tables is much more efficient:

kandidate metric:
 - read by other session
 - direct path read (sorts?)
 - db file parallel read
 - controlfile seq read

*/

SELECT
  TO_CHAR ( s2.snap_time, 'MON DD HH24:MI' )                                                     AS endtime
, ( e2a.time_waited_micro - e1a.time_waited_micro )/ (1000000 )                                          AS lfsyn_tot
, ( e2a.time_waited_micro - e1a.time_waited_micro )/ ( (e2a.total_waits - e1a.total_waits +1 ) * 1000 )  AS lfsyn_avg
, ( e2b.time_waited_micro - e1b.time_waited_micro )/ (1000000 )                                          AS lfpwr_tot
, ( e2b.time_waited_micro - e1b.time_waited_micro )/ ( (e2b.total_waits - e1b.total_waits +1 ) * 1000 )  AS lfpwr_avg
-- , s1.*
FROM
  stats$system_event e1a
, stats$system_event e2a
, stats$system_event e1b
, stats$system_event e2b
, stats$snapshot  s1
, stats$snapshot  s2
WHERE s1.dbid              = s2.dbid
  AND s1.instance_number   = s2.instance_number
  AND s1.startup_time      = s2.startup_time
  AND s1.snap_id + 1       = s2.snap_id
  AND s2.snap_time > TRUNC ( SYSDATE - 28 ) -- over the last 7 days
--   AND  s2.begin_interval_time = ( SELECT MAX (begin_interval_time) FROM sys.wrm$_snapshot) -- is s2 the latest ?
  AND e1a.snap_id         = s1.snap_id
  AND e1a.dbid            = s1.dbid
  AND e1a.instance_number = s1.instance_number
  AND e2a.snap_id         = s2.snap_id
  AND e2a.dbid            = s2.dbid
  AND e2a.instance_number = s2.instance_number
  AND e2a.event           = e1a.event
  AND e1a.event        LIKE 'log file sync%'
  AND e1b.snap_id         = s1.snap_id
  AND e1b.dbid            = s1.dbid
  AND e1b.instance_number = s1.instance_number
  AND e2b.snap_id         = s2.snap_id
  AND e2b.dbid            = s2.dbid
  AND e2b.instance_number = s2.instance_number
  AND e2b.event           = e1b.event
  AND e2b.event        LIKE 'db file sc%'
ORDER BY s1.snap_id 
/
