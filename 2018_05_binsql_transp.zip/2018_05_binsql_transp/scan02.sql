doc
    scan02.sql

    Current users & processes.
#

column usrnm		format  A10 trunc heading USERNAME
column osusr		format  A10	trunc
column machine		format  A14	trunc
column program		format  A20	trunc
column logon_time 	format 	A20
column spid		format 	A7 heading Unix-Id|Or-Spid
set heading on
set pagesize 60
select 	nvl ( s.username, 'background' )  		   usrnm 
,		s.osuser				   osusr
, 		s.machine				   machine
,		s.program 				   program
,		p.spid					   spid
,       to_char(s.logon_time, 'DD-MON-YYYY HH24:MI:SS') logon_time
from v$session 	s
,    v$process	p
where	1=1
and 	s.paddr = p.addr
order by p.spid
/

clear columns
prompt
