
DROP PACKAGE DD_PKG;

CREATE OR REPLACE PACKAGE dd_pkg
as

procedure main ( v_in_filename varchar2 ) ; 

end dd_pkg;
/

show errors


CREATE OR REPLACE PACKAGE BODY dd_pkg
as




PROCEDURE main ( v_in_filename varchar2 )
as
  starttime	date ;
  vc_result        varchar2(64) ;
  vc_sid        varchar2( 5) ;
  vc_key	varchar2(32) ;
  n_counter	number := 0 ;
  n_dups	number := 0 ;

begin

  dbms_output.put_line ( 'main : start.' );

  null ;

end ;


end dd_pkg;
/


show errors

