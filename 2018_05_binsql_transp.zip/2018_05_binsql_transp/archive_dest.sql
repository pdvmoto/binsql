
rem set archive destinatin to something sensible..

-- ------------------------
-- using the recovery-file-dest:

-- alter system set db_recovery_file_dest='C:\TEMP\' scope=both ;

-- alter system set  DB_RECOVERY_FILE_DEST_SIZE=10G  scope=both ;

-- alter system set db_recovery_file_dest='F:\oracle\product\10.2.0\flash_recovery_area\IDBPA\ARCHIVELOG' scope=both ;

-- -------------------
-- using log_archive_dest_n
-- this seems to use the conventional "format" as well

-- alter system set log_archive_dest_2 =' ' scope=both ;
-- alter system set log_archive_dest_1 ='LOCATION=C:\TEMP\DB10\ MANDATORY' scope=both ;
-- alter system set log_archive_dest_1 ='LOCATION=F:\oracle\product\10.2.0\flash_recovery_area\IDBPA\ARCHIVELOG\ MANDATORY' scope=both ;

-- alter system set log_archive_dest_1 ='LOCATION=Y:\Oracle\IDBPA\archives\ MANDATORY' scope=both ;


-- alter system set log_archive_dest_state_1=enabled scope=both;


-- alter system set archive_lag_target=900 scope=both ;


