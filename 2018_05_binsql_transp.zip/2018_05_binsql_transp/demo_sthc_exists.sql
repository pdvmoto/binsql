
-- 
--
-- 

set echo on

select 'Exists' from HEAP  
where KEY = 'ONE' 
/
set echo off
set autotrace on
/
set autotrace off

prompt
prompt An "exist" check is relatively easy, 
prompt on a heap table it would use the PK and get 3 blocks or so...
prompt
pause now press enter to look at the STHC...

set echo on
select 'Exists' from CLUT  
where KEY = 'ONE' 
/
set echo off
set autotrace on
/
set autotrace off


prompt
prompt so... an "exist" check on a STHC is very efficient, 
prompt it does not use the PK but goes in on the Hash - 1 block !
prompt
prompt Great. 
prompt But why do I still need that PK index ?
prompt
pause now could I delete the PK (unique) index ?

set echo on

drop index clut_pk ;

set echo off

prompt 
prompt Can I ?
prompt apparently I have to remove the constraint first..
prompt
pause lets drop the constraint then...

set heading on

set verify off

--@segsize clu
select segment_name, bytes / (1024 ) as KB, blocks
from user_segments where segment_name like 'CLU%';

set echo on

alter table clut drop constraint clut_pk ;

set echo off

--@segsize clu
select segment_name, bytes / (1024 ) as KB, blocks
from user_segments where segment_name like 'CLU%';

prompt 
prompt I dropped the constraint, the index is gone.
prompt I have one less segment to maintain and to buffer, 
prompt but I am not able to enforce a PK/UK without it ! 
prompt
Prompt ... on my wishlist to Oracle: STHc without PK-index
prompt

pause end of exist-demo press enter to re-creat PK just in case.

prompt  repair the constraint, just in case
alter table clut add constraint clut_pk primary key ( key ) ; 

