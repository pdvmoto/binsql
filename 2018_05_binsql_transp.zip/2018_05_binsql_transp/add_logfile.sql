
alter logfile add member 'C:\ORACLE\PRODUCT\10.2.0\ORADATA\DB10\REDO01a.LOG' to group 1;
