/*

Demonstrate :
 - how PK or unique constraint can be enforced with non-unique index.
 - how extra table-access increases logical IO and cost.
 
When to use:
 - if table-access is via PK-fields, but _always_ requires extra non-pk field.

*/

set echo on
set pagesize 100

spool pk_overload

drop table ovl;

create table ovl as select * from all_objects order by dbms_random.value ;

create index ovl_pk on ovl ( owner, object_name, subobject_name, temporary, generated, secondary );

alter table ovl add constraint ovl_pk primary key ( owner, object_name, subobject_name ) using index ovl_pk ;

analyze table ovl compute statistics ;

-- do qry twice to reduce effect of recursive sql at parse.

select object_name, avg_row_len from ovl 
where owner like 'SY%' and temporaru = 'T' 
/

select * from table(dbms_xplan.display_cursor); 

set autotrace on stat 

select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/

set autotrace off



alter table ovl drop constraint ovl_pk ;

drop index ovl_pk ;

create index ovl_pk on ovl ( owner, table_name, num_rows, avg_row_len);

alter table ovl add constraint ovl_pk primary key ( owner, table_name ) using index ovl_pk ;

-- do qry twice to reduce effect of recursive sql at parse.

select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/

select * from table(dbms_xplan.display_cursor); 

set autotrace on stat 
select table_name, avg_row_len from ovl 
where owner like 'SY%' and num_rows > 100000 
/

set autotrace off

-- Even if we Still have to access the table..
-- we have reduced the nr of accesses.

select table_name, avg_row_len, pct_used from ovl 
where owner like 'SY%' and num_rows > 100000 
/

select * from table(dbms_xplan.display_cursor); 

set autotrace on stat 
select table_name, avg_row_len, pct_used from ovl 
where owner like 'SY%' and num_rows > 100000 
/

set autotrace off


spool off
