
spool demo_sthc

/*
demo of difference in access on Equal Predicate,
between Heap, IOT and Single-table-hash-cluster (fastest?)

pre-reqs:
 - fairly large table (100M+, but reduced demo to 64K)
 - static, predictable contents.
 - long-ish irregular varchar2 key
 - relatively small records (reduced demo to 20-padding)

Additional ideas:
 - test reverse index as well
 - test multy-key PK (e.g. parent + child)
 - test impact of growing record-size, 
 - test effect of too-many-keys, 
 - test non-equal predicates (the PK index saves the day)
*/

set linesize 120
set pagesize 0
set echo on

drop table   heap ;
drop table   iotb ;
drop table   clut ;
drop cluster clu ;

-- first the heap

create table heap as 
select 
  to_char (to_date ( rownum, 'J'), 'JSP' )  as key  --note the non-random distribution of the key
, rownum  as num_key
, sysdate +  ( dbms_random.value ( -100.0, 100.0) ) as date_modified
, rpad ( to_char ( dbms_random.value ) || ' ' || to_char ( dbms_random.value ), 20 )  as padding
from dual 
connect by level < ( 64 * 1024)
/

create unique index heap_pk on heap ( key ) ;
alter table heap add constraint heap_pk primary key ( key )  ;

-- now IOT
CREATE TABLE IOTB
(
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint iotb_pk primary key ( key)
)
organization index
/

insert into iotb select * from heap ;
commit ;


-- now cluster
create cluster clu ( key varchar2(78 byte) ) 
single table 
size 100
hashkeys 80000;

CREATE TABLE clut (
  key            VARCHAR2(78 BYTE),
  num_key        NUMBER,
  date_modified  DATE,
  padding        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

insert into clut select * from heap ;
commit ;

--
-- all objects created and filled..
--
Pause press enter to continUe...


select * from heap
where key = 'FIVE HUNDRED' 
/
set autotrace on
/
set autotrace off

--
-- Heap Table. 
-- notice the excution-plan, index + table 
-- and the nr of gets.
--
pause press enter to run same query against IOT

select * from iotb
where key = 'FIVE HUNDRED'
/
set autotrace on
/
set autotrace off

--
-- Index Organized Table: 
-- notice the IOT is slightly more Efficient...
-- compare the plan and the nr of gets.
--
pause press enter to run against the STHC


select * from clut
where key = 'FIVE HUNDRED'
/
set autotrace on
/
set autotrace off


-- 
-- ... but the Cluster does the Absolute Minimal Consistent Gets.
--
-- That was the main demo.
--
-- Now try something: select more then one row,
-- will cluster still be efficient ?
--
-- (next slide please)
--
pause  press enter... to see a less efficient qry

select * from heap
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off

--
-- On heap table: that was predictable..
-- Index + table
--
pause Press enter to go qry IOT

select * from iotb
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off

--
-- On IOT : predictable..
-- Index
--
pause Press enter to go qry STHC


select * from clut
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off


--
-- when selecting 2 rows, the Cluster is suddenly just as (in)efficient as the Heap.
-- guess what: it is using the PK...
--
pause press enter to mess with the PK 

--
-- suppose I had forgotten the pk...
--

alter table clut drop constraint clut_pk;

--
-- no more PK...
--
pause  press enter to select 2 records, wihtout help from PK... 


select * from clut
where ( key = 'FIVE HUNDRED' or key = 'SEVEN THOUSAND' ) 
/
set autotrace on
/
set autotrace off

--
-- Without the PK it reverts to .... FTS!
-- Not very clever, is it ?
-- 
-- let me try one more thing... UNION.
--
pause press enter to re-write the qry slightly.

select * from clut
where key = 'FIVE HUNDRED'
                             UNION 
select * from clut
where key = 'SEVEN THOUSAND' 
/

pause this was the same Question, written as a Union

set autotrace on
/
set autotrace off

--
-- so.. with the Union of two "efficient" queries, 
-- I seem to have fixed this. 
--
-- Why Me ?
-- 
pause press enter to recap


-- RECAP:
-- 
-- The STHC is The Most Efficient way to get to a record,
-- but...
-- If and Only IF we go in on an equal predicate (and then some..).
--


spool off
