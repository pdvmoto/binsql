
select 'rm ' || file_name from sys.dba_data_files ;

select 'rm ' || file_name from sys.dba_temp_files ;

select 'rm ' || member from v$logfile ;

select 'rm ' || name from v$controlfile ;

