-- 
-- purpose: demo fk and locking when index is missing
--


drop table iwl; 
drop table i ;
drop table l;

create table i as
(select rownum i_id, object_name as i_name, created from dba_objects 
where owner = 'MLLSYSTEM' 
and object_type = 'TABLE'  ); 

alter table i add constraint i_pk primary key ( i_id ) using index ;

create table l as
( select rownum as l_id, object_name l_name, created 
from dba_objects where owner='MLLSYSTEM' and object_type = 'INDEX'
) ; 

alter table l add constraint l_pk primary key ( l_id ) using index ;

create table iwl as 
(select rownum iwl_id
, i.i_id
, l.l_id
, ic.column_name
, ic.column_position
, sysdate as created
from i, l, dba_ind_columns ic
where ic.index_owner = 'MLLSYSTEM'
and   ic.table_name = i.i_name
and   ic.index_name = l.l_name );


alter table iwl add constraint iwl_pk primary key ( iwl_id ) using index ;

alter table iwl add constraint i_fk foreign key ( i_id ) references i ( i_id ) ; 

alter table iwl add constraint l_fk foreign key ( l_id ) references l ( l_id ) ; 


-- all objects created, but no indexes on FK-columns in child-table.


-- now try :
-- 
-- delete data from child table, e.g. all values l_id > 1000
-- update L-parent (cause lock) where l_id > 1000 (so no kids present)
-- and then try updateing some random iwl: whole table is locked due to update of parent!
-- 
