/*

file : demo_sqlplan

Demonstrate : 
 - change of plan : same SQL, 2 plans..

*/

alter session set optimizer_mode = first_rows;

set echo on
set pagesize 100
set linesize 100
column table_name format A30


spool demo_index

clear screen

-- drop and recreate the table with a 2-field PK, typical parent-child.

--drop   table OVL;
create table OVL as 
select OWNER, TABLE_NAME, TABLESPACE_NAME
     , IOT_TYPE, IOT_NAME, NUM_ROWS, AVG_ROW_LEN
     , LAST_ANALYZED, STATUS
from all_tables order by dbms_random.value ;

create unique index OVL_PK on OVL ( OWNER, TABLE_NAME );
alter table OVL add constraint OVL_PK primary key ( OWNER, TABLE_NAME ) using index ovl_pk ;

-- Index and constraint added.
-- first pass of the qry is a good moment to use display_cursor.
-- second pass of the qry we will use autotrace-stats to see IO.
accept press_enter prompt "press enter to continue..."

select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

-- set, hope for full table scan
alter session set optimizer_mode = all_rows ; 

select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

accept press_enter prompt "press enter to continue..."

-- set, hope for index
alter session set optimizer_mode = first_rows ; 

select 
	owner, table_name, num_rows
from 	ovl
where   owner = 'DBSNMP'
/
select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        


spool off
