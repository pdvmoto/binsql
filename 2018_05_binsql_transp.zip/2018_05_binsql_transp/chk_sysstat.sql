

/*

find system statistics sql.

Addition: collection of statistics from variou systems.

needs a table:
create table sysstats_compare as 
select global_name, sysdate as collection_date, s.*
from sys.aux_stats$ s
, global_name 
where rownum < 1 ;

needs some insert-statements, generated... see bottom of script


*/
   
set feedb off
set head off
set pagesize 200

spool do_chk_sysstat.sql

prompt
prompt set feedb off
prompt set head on

-- make sure spoolfile is unique and contains database and server.
SELECT  'spool '
|| to_char ( sysdate, 'DD_MON_YY_HH24MISS' )
 || '_sysstatsL_for_' ||db.name|| '_'
 || RTRIM(SUBSTR ( p.program, INSTR ( p.program, '@' ) + 1
                        ,   INSTR ( p.program, ' ' )
                            -  INSTR ( p.program, '@' )  ) )
FROM    v$database      db
,       global_name     gn
,       v$process       p
where p.program LIKE '%(PMON)%' ;


prompt
prompt @date
prompt 

prompt prompt
prompt prompt

prompt
prompt @where
prompt

prompt column sname format A15
prompt column pname format a12
prompt column pval1 format 99999999.999
prompt column pval2 format A25 truncated

prompt set feedb on
prompt set head on

select 'select * from sys.aux_stats$ ;' from dual ;


spool off

-- now generate the spoolfile with first lines...

@do_chk_sysstat

-- now spool insert-stmnts to collect statistics.

set linesize 255
set termout off

select 'dbms_stats.set_system_stats(pname => '''' 
|| pname 
|| ''', ''' || pval1 
|| ''' );'
from sys.aux_stats$ s
, global_name ;


spool off

