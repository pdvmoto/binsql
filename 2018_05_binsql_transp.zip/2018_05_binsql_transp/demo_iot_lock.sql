
drop TABLE PARENT_IOT;
drop TABLE CHILD_OF_IOT;

Drop table PARENT_HEAP;
drop table CHILD_OF_HEAP;

create table parent_iot (
  id number(10) primary key,
  v varchar2(10) not null
) organization index;

create table child_of_iot (
  id number(10) primary key,
  p_id number(10) not null references parent_iot (id),
  v varchar2(10) not null
);


create index child_of_iot_parent_id on child_of_iot (p_id);


insert into parent_iot values (1, '1');
insert into parent_iot values (2, '2');
insert into child_of_iot values (1, 1, '1');
insert into child_of_iot values (2, 1, '2');
insert into child_of_iot values (3, 2, '3');

	
create table parent_heap (
  id number(10) primary key,
  v varchar2(10) not null
) ;

create table child_of_heap (
  id number(10) primary key,
  p_id number(10) not null references parent_heap (id),
  v varchar2(10) not null
);

create index child_of_heap_parent_id on child_of_heap (p_id);


insert into parent_heap values (1, '1');
insert into parent_heap values (2, '2');
insert into child_of_heap values (1, 1, '1');
insert into child_of_heap values (2, 1, '2');
insert into child_of_heap values (3, 2, '3');


