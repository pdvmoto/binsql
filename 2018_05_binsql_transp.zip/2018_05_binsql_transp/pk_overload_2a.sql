
--
-- notice: to prove skeptics that the PK is still in effect..
--
--
insert into ovl 
select owner, table_name, tablespace_name, iot_type, iot_name, num_rows, avg_row_len, last_analyzed, status
from all_tables ;

insert into ovl ( owner, table_name ) values ('SYS', 'DUAL' );
 
