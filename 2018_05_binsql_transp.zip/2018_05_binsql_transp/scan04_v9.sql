doc
    scan04_v9.sql

    Transaction volume for last 50 log switches. 
    (If available in v$log_history).
    - less then 900 seconds per switch is "fast", consider larger logfiles
    - Last column > 100.0 is considered "high volume"
      examine batches, try to spread (batch) load over time
#
column switch           format a22
column sec		format 99999
column ch_per_sec	format 9999.999
column kb_per_sec	format 999,999.9
column graph            format a38

set heading on
set feedback on
set pagesize 120

select 	to_char(lh2.first_time, 'MM/DD/YYYY HH24:MI:SS')				switch
,	( lh2.first_time - lh1.first_time ) * 3600 * 24 				sec 
,	( l.bytes / 1024  )/( ( lh2.first_time	- lh1.first_time ) * 3600 * 24 )	kb_per_sec 
,       lpad ('*' 
             , log (100000,  (l.bytes / 1024  )/( ( lh2.first_time	- lh1.first_time ) * 3600 * 24 ) ) * (40)
             , '*' 
             ) as graph
from 	v$log_history lh1
, 		v$log_history lh2
,		v$log		l
where lh1.sequence# = lh2.sequence# -1
and     (lh2.first_time - lh1.first_time) * 3600 * 24  > 0     /* min. 60 avoids hot bck peaks */
and 	l.status = 'CURRENT' 		/* assume  all groups equal file-sizes */
and lh1.sequence# > l.sequence# - 152
order by lh1.sequence# 
/

set pagesize 14
clear columns
prompt
