
column sid format 9999
column username format A20
column opname format a30
column perc format 999.99

select sid, username, opname, round ( sofar / totalwork , 2 ) * 100 as perc
--, l.*
from v$session_longops l
where sofar <> totalwork
/

