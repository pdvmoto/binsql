rem
rem adhoc snapshots for AWR
rem

@time 

rem execute perfstat.statspack.snap ( i_ucomment => 'my snapshot' );   

execute sys.DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT ();



