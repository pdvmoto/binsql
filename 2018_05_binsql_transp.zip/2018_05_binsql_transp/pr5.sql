
set serveroutput on 
set feedback off

variable PS1 varchar2(32);


/*
SELECT 'set sqlprompt "' || user || ' @ ' ||global_name||' '
       || ' > "'
FROM        global_name     gn
/

SELECT 'host title "' || user || ' @ ' ||global_name||' '
       || ' > "'
FROM        global_name     gn
/

*/ 

spool sqlstart


declare 

   vc_sqlprompt 	varchar2(128);
   
   vc_titleprompt 	varchar2(128);
   
   vc_cdb_yn          	varchar2(10);
   vc_add_cdbinfo     	varchar2(64) := ' ' ;

begin

-- determine if we are in a CDB , if so: USER @ DB:container(con_id)
-- e.g. : system @ cdb1:pdb2(5) > 


SELECT 'set sqlprompt "' || user || ' @ ' || db.name
into vc_sqlprompt
FROM        v$database     db;

  -- now determine cdb or not, trap error
  begin
    select 
	':'|| sys_context ('USERENV', 'CON_NAME' ) ||
       '(' || sys_context ('USERENV', 'CON_ID'   ) || ')' 
   into vc_add_cdbinfo
   from dual ;
  
  exception 
	when others then null ;
  end;

-- finialize the prompts:
vc_sqlprompt := vc_sqlprompt || vc_add_cdbinfo || ' >"';

-- spit it out

dbms_output.put_line (vc_sqlprompt); 

end;
/


spool off

-- run and reset

@sqlstart.lst

set heading on
set feedback on


declare 

   vc_sqlprompt 	varchar2(128);
   
   vc_titleprompt 	varchar2(128);
   
   vc_cdb_yn          	varchar2(10);
   vc_add_cdbinfo     	varchar2(64) := ' ' ;

begin

-- determine if we are in a CDB , if so: USER @ DB:container(con_id)
-- e.g. : system @ cdb1:pdb2(5) > 


SELECT 'set sqlprompt "' || user || ' @ ' ||global_name
into vc_sqlprompt
FROM        global_name     gn;

  -- now determine cdb or not, trap error
  begin
    select 
	':'|| sys_context ('USERENV', 'CON_NAME' ) ||
       '(' || sys_context ('USERENV', 'CON_ID'   ) || ')' 
   into vc_add_cdbinfo
   from dual ;
  
  exception 
	when others then null ;
  end;

-- finialize the prompt:
vc_sqlprompt := vc_sqlprompt || vc_add_cdbinfo || ' >"';

-- spit it out
dbms_output.put_line (vc_sqlprompt); 

end;
/ 
