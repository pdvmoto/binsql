

select 'alter user ' || name || ' identified by values ( ''' ||
password || ''' ) '
from sys.user$
order by name;