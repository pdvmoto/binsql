
set doc on
set heading off
set feedback off
set verify off
column listfile heading "Listfile"  new_value listfile format a40;

spool db_info_spool.lst
select 'spool db_scan_'||name||'_'||to_char(sysdate,'YYYYMMDD_HH24_MI') listfile 
from v$database;

spool off
@db_info_spool.lst

variable listfile varchar2(40);
begin 
  :listfile := '&listfile';
end;
/

remark AAA$READ.ME
doc

	Generate quick database overview
	spoolfile : db_scan.lst
	(c) LogicaCMG 1998-2005
        Version 10g: 01/12/2005

#

set linesize 80
-- set pagesize 200
set heading on

@@info01_v7.sql

rem yuri's quickscan, with some additions
@@buffcach.sql
@@dictcach.sql
@@rbscont.sql
@@libcache.sql
@@redolog.sql
@@latchcon.sql
@@parsecr_v7.sql
@@disksort.sql
@@contfr.sql
@@fulltsr.sql
@@dbwrchk_v7.sql

set heading on
set feedback on

@@scan02.sql
@@scan03.sql
@@scan04_v7.sql
@@scan05_windows.sql
@@scan06.sql
@@scan07.sql

spool off

prompt Listfile is in &listfile..lst
