prompt No correct database or OS version could be determined. 
prompt Please report to LogicaCMG ORC (+31 70 3029333).
