connect SYS/change_on_install as SYSDBA

spool /tmp/crdbPDS06_part2.log

-- CLUSTER_DATABASE !!!!!

-- Place the database into archive log mode 

connect / as sysdba
shutdown immediate
startup mount EXCLUSIVE
alter database archivelog;
shutdown

spool off
