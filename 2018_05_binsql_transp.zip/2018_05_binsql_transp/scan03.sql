doc
    scan03.sql

    Object locks

    This script displays since when an object is locked in the database
    including the oracle username, os username, sid and lockmode.

#

col oracle_username format a15
col os_user_name format a15
col object_name format a20
col sid format 999
col locked_mode format a4 heading LOCK|MODE
col since format a17
set heading on
set feedback on

select l.oracle_username
,      l.os_user_name
,      l.session_id sid
,      obj.object_name
,decode(l.locked_mode,1,'null',
	2,'rs',
	3,'re',
	4,'sh',
	5,'shre',
	6,'excl') locked_mode
,       t.start_time since
from v$locked_object l
,    dba_objects obj
,    v$transaction t
where 	l.object_id = obj.object_id (+)
and     t.xidusn = l.xidusn
/

clear columns
prompt
