
--define datafile=C:\ORACLE\ORADATA\DB02\USER01.DBF
--define datafile=C:\ORACLE\ORADATA\DB02\UNDO01.DBF
--define datafile=C:\ORACLE\ORADATA\DB02\SYSAUX_01.DBF

-- define DATAFILE = C:\ORACLE\PRODUCT\10.2.0\ORADATA\DB10\USERS01.DBF

-- funny max-bytes value...
define DATAFILE=/oracle/db/ansprt/data/ts01/EPPTM01.dbf                                                                            
        
alter database datafile '&DATAFILE' RESIZE 2000M ;
alter database datafile '&DATAFILE' autoextend on next 500m maxsize 4000M ;

