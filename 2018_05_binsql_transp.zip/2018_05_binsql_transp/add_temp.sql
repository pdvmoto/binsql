alter tablespace temp add datafile 
'/d02/oradata/bdp.db/tempbdp2.dbf' size 40m;
