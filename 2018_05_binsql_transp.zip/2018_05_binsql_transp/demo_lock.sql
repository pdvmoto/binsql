
set doc on
set echo on

DROP TABLE dl ;

CREATE TABLE dl 
( dl_id NUMBER
, dl_payload VARCHAR2(32) 
, primary key ( dl_id) 
) ;

INSERT INTO dl VALUES ( 1, 'first' );

/* ------------------------------------------------------

  You now have a table with one  records, uncommitted
 
 in 2nd session : paste this :

INSERT INTO dl VALUES ( 1, 'first' );
-- and it will hang until the first sesion commits.
 
-- or paste this
INSERT INTO dl VALUES ( 2, 'second' );
-- and it will continue with nor problem

-- as an aside, you can demo the (lack of) isolation level by doing 
select * from dl ;
-- in both sessions: you see perfectly legal different results..

  -----------------------------------------------------
*/
   
ACCEPT pause

/* -----------------------------------------------------------

more on deadlocks: see deadlock.sql for demo of deadlocks

   Find out which session reported the deadlock, and why....
   Also go and find out what is in the alert and tracefiles.

   Tracefile (udump) will tell you it is Always an application-error 
   (just to support our claim: it is the app!).
   

   Keep in mind the following:   

   1. There is very little a database can to to prevent 
      deadlocks: only te app can prevent them..
      The app should lock (or at least try to lock)
      all data before updating (for update [nowait] ).
 
   2. A slow system increases the risk of deadlock:
      transacton take longer, locks are held longer,
      and changes of other proceses interfering increase.
      
   3. Single-tread or single-batch systems can avoid
      deadlocks but are only a workaround, not a fix. 
          
   Good lock !
   
   PdV

   -----------------------------------------------------------
*/ 





