
/*
File : demo_syn.sql

Purpose: 
	Show that creating a synonym generates a commit.
*/

drop table abc ;
drop synonym def ;

create table abc as select * from dual ;

select * from abc ;

insert into abc values ( 2) ;

set doc on
/* 

Now open second sql-plus window, 
and verify that the insert of "2" has not been committed yet,
copy in following:

SQL> select * from abc ;

and come back here...
*/


prompt and hit entere here to create a synonym....
accept anything

create synonym def for abc ;

select * from def ;

/* 
Now go into the 2nd window again and hit "/" to re-query ABC,
Did any data get committed ?

*/
