doc
	info02G.sql

	Sizing info: Sizes and Kb usage of tablespaces
#

set heading on
set feedback off
set lines 80

column	tablespace_name format a22
column	Gfree		format 99,999,999,999
column	Gused		format 99,999,999,999
column	Gtotal		format 99,999,999,999
column	pct_fr		format 999.99

select  ts.tablespace_name 
     , ts.total - df.free as Gused
     , ts.total           as Gtotal
     , 100 * (df.free) / ts.total pct_fr
     , df.free            as GFree 
from ( select sum ( t.bytes /( 1024*1024*1024 )) total, t.tablespace_name tablespace_name  
       from dba_data_files t
       group by t.tablespace_name ) ts
   , ( select sum ( f.bytes / ( 1024*1024*1024 )) free, f.tablespace_name
       from dba_free_space f
       group by f.tablespace_name ) df
where df.tablespace_name = ts.tablespace_name       
order by 1 ;

set head off

column	sGfree		format 999,999,999
column	sGused		format 999,999,999
column	sGtotal		format 999,999,999
column	sperc_free	format 99.99 head perc_free

select '                               '||'------------'||' '||'------------'||' '||'------------'||' '||'---------' from dual;
select '                        Total:'
, sum(Gused)                    sGfree
, sum(GTotal) sGused
, 100* sum(Gfree) / sum(GTotal) sPerc_free 
, sum (Gfree) sGfree
from
(
select  ts.tablespace_name 
     , df.free            as GFree 
     , ts.total - df.free as Gused
     , ts.total           as Gtotal
from ( select sum ( t.bytes /( 1024 *1024*1024 )) total, t.tablespace_name tablespace_name  
       from dba_data_files t
       group by t.tablespace_name ) ts
   , ( select sum ( f.bytes / ( 1024 *1024*1024)) free, f.tablespace_name
       from dba_free_space f
       group by f.tablespace_name ) df
where df.tablespace_name = ts.tablespace_name        )
;


-- additional for temp-ts...
select  ts.tablespace_name
     , 0                  as MFree
     , 0                  as Mused
     , ts.total           as Mtotal
     , 100                as pct_fr
from ( select sum ( t.bytes /( 1024 *1024 )) total, t.tablespace_name tablespace_name
       from dba_temp_files t
       group by t.tablespace_name ) ts
where 1=1
order by 1 ;


set heading on
set feedback on
clear columns

prompt
