
-- check if we can see the AWR package ? 
-- if we can see doesnt mean we can also excute, but is good start

desc dbms_workload_repository