
doc
	info07.sql : Relevant init-parameters - adjusted for EC

	call from : info_ec

	Remarks :
	- Inserted 1 set (first set) specifically for EC,  based on XLS.

	- This list is/was mostly performance oriented.

#


set pagesize 79

-- already in calling scripts.. @info01_v10

column name		format A35 trunc
column value		format A15 wrap
column nls_value	format A30 wrap
column dflt		format A4 justify left
column Sesmod		format A6 trunc head sesmod justify right
column sysmod		format A6 trunc head sysmod justify right

column descript		format A26 trunc

 
/***

 approximate list of parameters for EC

***/


SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , lpad ( value, 15 )
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'processes%') 
        OR (p.name like 'cpu%')
        OR (p.name Like 'db_block%')	   
	OR (p.name Like 'sga_%')	   
	OR (p.name Like 'sga_%')	   
	OR (p.name Like 'shared_pool%')	   
        OR (p.name Like 'db_cache%')	   
        OR (p.name Like 'shared_ser%')	   
        OR (p.name Like 'job_queu%')	   
        OR (p.name Like 'parallel_max%')	   
        OR (p.name Like 'parallel_serv%')	   
        OR (p.name Like 'optimizer%')	   
        OR (p.name Like 'open_cursors%')	   
        OR (p.name like 'resource%')
        OR (p.name Like 'pga%')	   
    )
ORDER BY p.name
/

/***
processes
sga_max_size
shared_pool_size
shared_pool_reserved_size
sga_target
db_block_size
db_cache_size
shared_servers
job_queue_processes
parallel_max_servers
optimizer_features_enable
open_cursors
optimizer_mode
pga_aggregate_target
parallel_servers_target
***/


doc

        show sga size

        note: values may differ from set-parameter (??)
        this is acutal claimed amount.

#

select nvl ( pool, name )                        as name
     , to_char ( sum(bytes),  '9,999,999,999' ) as value
from v$sgastat
where 1=1 -- pool is not null
group by nvl ( pool, name ) 
/

select 'Total SGA'                               as name
     , to_char ( sum(bytes),  '9,999,999,999' ) as value
from v$sgastat
where 1=1 -- pool is not null
group by 'Total SGA'
/


doc

	show auto-adjusted values, order by parameter.

	note: long lists and large changes are a negative sign.
#

column parameter	format A35 trunc
column start_time       format A15
column oper_type        format A12
column GB               format A10

select 
  parameter 
, oper_type
, to_char ( start_time ,  'MM MON DD HH24:MI' ) start_time
, to_char ( final_size/(1024*1024*1024) , '9.99' ) GB
-- * 
from v$memory_resize_ops 
where parameter in ('db_cache_size', 'shared_pool_size', 'java_pool_size', 'streams_pool_size' )
or 1=1 
order by component, start_time ;


-- exit for the moment 
-- exit

/***
-- shnow Container and visible PDBs

-- container
select con_id, name from v$container ; 

-- pdb
select pdb_id, pdb_name, status -- * 
from sys.cdb_pdbs  ; 
**/



-- rest of scripts.. for later reference.

SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , lpad ( value, 15 )
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'always_anti%') 
	OR (p.name Like 'aq%')	   
	OR (p.name Like 'arch%')	   
	OR (p.name Like 'audit%')	   
        OR (p.name Like 'char%')	   
        OR (p.name Like 'checkpoint%')	   
        OR (p.name Like 'control_management_p%')    
        OR (p.name Like 'cpu%')    
        OR (p.name Like 'cursor%') 
	OR (p.name Like 'db_block_b%') 
	OR (p.name Like 'db_block_s%')  
	OR (p.name Like 'db_block%')  
        OR (p.name Like 'db_crea%')    
	OR (p.name Like 'db_%cach%')  
	OR (p.name Like 'db_f%') 
	OR (p.name Like 'db_wr%') 
	OR (p.name Like 'dbwr%') 
	OR (p.name Like 'flash%') 
	OR (p.name Like 'global%') 
	OR (p.name Like 'hash%') 
	OR (p.name Like 'java%') 
	OR (p.name Like 'job%') 
	OR (p.name Like 'large%') 
	OR (p.name Like '%keep%') 
	OR (p.name Like 'loc%') 
	OR (p.name Like 'log_archive_b%') 
	OR (p.name Like 'log_archive_s%') 
	OR (p.name Like 'log_bu%') 
	OR (p.name Like 'log_ch%') 
	OR (p.name Like 'log_s%') 
	OR (p.name Like 'memory%') 
	OR (p.name Like 'mts%') 
	OR (p.name Like 'max%') 
	OR (p.name Like 'nls_date%') 
	OR (p.name Like 'nls_leng%') 
	OR (p.name Like 'opti%') 
	OR (p.name Like 'open%') 
	OR (p.name Like 'os%') 
	OR (p.name Like 'pga%') 
	OR (p.name Like 'proc%') 
	OR (p.name Like 'query%')
        OR (p.name Like 'resource%')
	OR (p.name Like '%passw%') 
	OR (p.name Like 'shared%') 
	OR (p.name Like 'sga%') 
        OR (p.name like '%smal_table%')
	OR (p.name Like 'snap%') 
	OR (p.name Like 'sort_a%') 
	OR (p.name Like '%spin%') 
	OR (p.name Like 'seq%')  
	OR (p.name Like 'serv%')  
	OR (p.name Like 'session_c%')  
	OR (p.name Like 'star%') 
	OR (p.name Like 'stat%') 
	OR (p.name Like 'timed_sta%') 
	OR (p.name Like '_trace%') 
	OR (p.name Like 'undo%') 
	OR (p.name Like 'work%')
	OR ( substr ( p.name, 1, 1) = '_' )  -- show any hidden params
 	)
ORDER BY p.name
/


doc

	generic database parameters	
#
--   - startup : ifile, spfile, control, compatible, db_domain, db_files, db_name, processes

SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , lpad ( value, 15 )
           )                                                          value
 , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		      descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'compatible%')
     -- OR (p.name Like 'control_file%')	   
	OR (p.name Like 'db_d%')
     -- OR (p.name Like 'db_files%')	
	OR (p.name Like 'db_na%')	
        OR (p.name Like 'ifile%')	   
	OR (p.name Like 'optimizer_mode%')	 	   
	OR (p.name Like 'spf%')	   
     -- OR (p.name Like 'processes%')	   
	)
ORDER BY p.name
/


doc

	db_cache related parameters	
#

SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , lpad ( value, 15 )
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		      descript
FROM v$parameter p
WHERE 1 = 1
and (   (p.name    in ( 'db_cache_size'
                      , 'db_2k_cache_size'
                      , 'db_4k_cache_size'
                      , 'db_8k_cache_size'
                      , 'db_16k_cache_size'
                      , 'db_32k_cache_size'
        )             )
     OR (p.name Like 'db_cache_ad%')
     OR (p.name Like 'db_block%')
  -- OR (p.name Like 'statistics%')
     OR (p.name Like 'buffer%')
     )
order by p.name
/

	
   
doc

	Nls and date related parameters.
#
SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , value 
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		      descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'nls%') 
	OR (p.name Like '%char%')	   
	OR (p.name Like '%date%')	   
	)
ORDER BY p.name
/

doc
	and additional nls_parameters
#
select parameter name
     , value 	 nls_value 
from v$nls_parameters 
order by parameter;

doc

  compare NLS parameters between spfile, db, instance and session.
#



column pname   format A17 trunc
column db_val  format A20 trunc
column inst_val format A20 trunc
column ses_val  format A20 trunc 
column init_val format A20 trunc
column ismod    format A5  trunc

set linesize 150

with SP_param as
(  select upper( name ) parameter, value, ismodified
  from v$parameter 
  where name like 'nls%'
union all 
  select 'NLS_CHARACTERSET', '', '' from dual
union all 
  select 'NLS_NCHAR_CHARACTERSET', '', '' from dual
)
select d.parameter name
, d.value          db_val 
, i.value          inst_val
, s.value          ses_val
, sp.value         init_val
, sp.ismodified    ismod
from nls_database_parameters d
, nls_instance_parameters i
, nls_session_parameters s
, sp_param sp
where d.parameter = i.parameter (+) -- (n)char-set not in i or s,
and   d.parameter = s.parameter (+) -- hence outer join
and  sp.parameter = d.parameter
order by d.parameter; 


select * from dual;

doc

	Parallel execution related init-parameters 
#

SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , value 
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		      descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'paral%') 
	OR (p.name Like 'paral%')  
    )
--and p.name not like 'parallel_server%'
ORDER BY p.name
/

doc

	File-system related init-parameters 
		Help you find dumps and archives.
#

column name		format A27 trunc
column value		format A40
column def		format A7

SELECT 	p.name				
  , 	p.VALUE												value
  , 	decode ( p.ISDEFAULT, 'TRUE', 'Dflt', 'NonDflt' )	def
FROM v$parameter p
WHERE 1 = 1
and (      (1=0) 
	OR (p.name Like 'audit_file%') 
	OR (p.name Like 'control%') 
        OR (p.name Like 'db_crea%')    
	OR (p.name Like '%dump_dest%') 
	OR (p.name Like 'dg%') 
	OR (p.name Like '%dest%') 
	OR (p.name Like 'file%') 
	OR (p.name Like 'gc_file%') 
        OR (p.name Like 'log_archive_d%') 
	OR (p.name Like 'log_archive_f%') 
	OR (p.name Like 'max_dump%') 
	OR (p.name Like 'shadow%') 
	OR (p.name Like 'utl%') 
	)
ORDER BY p.name
/
