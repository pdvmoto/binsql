
set linesize 128

select 'exec dbms_system.set_sql_trace_in_session ( ' 
	|| SID || ',' 
	|| serial# || ', TRUE); -- ' || USERNAME || '/' || program
from v$session 
/
