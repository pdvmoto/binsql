
doc

   audcnt.sql
   Count of audit records (if > 7 days, need purging)

#
select          trunc (timestamp#)       aud_date
        ,       count( *)               aud_events
from sys.aud$
group by trunc(timestamp#)
/
