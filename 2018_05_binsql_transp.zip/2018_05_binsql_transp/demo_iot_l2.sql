-- suppose parent with p_id=1 is locked..

--insert into child_of_heap values ( 4, 1, '4' );
--insert into child_of_iot values ( 4, 1, '4' );

--update child_of_heap set v='upd' where id = 1 ; 

--update child_of_iot set v='upd' where id = 1 ; 

--update child_of_iot set p_id=1 where id = 1 ;

insert into child_of_iot values ( 5, 1, '5');
