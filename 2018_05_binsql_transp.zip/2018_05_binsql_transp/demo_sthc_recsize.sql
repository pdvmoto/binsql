column table_name    format A10
column num_rows      format 99,999,999
column blocks        format 999,999   
column empty_blocks  format 9,999    head empblck
column avg_space     format 9,999    head avgspc
column chain_cnt     format 9,999    head chncnt
column avg_rowlen    format 9,999    head avgrow

column segment_name     format A20
column partition_name   format A25
column bytes         format 99,999,999 
column kb            format 99999999 
column kbytes        format 99999999 
column extents	     format 9,999

-- first make sure we can handle larger records, 
-- and verify that storage doesnt change...

set autotrace off

drop table clut ;
drop cluster clu ;

set echo on

CREATE CLUSTER clu ( key varchar2(78 byte) ) 
  SINGLE TABLE 
    SIZE 100
HASHKEYS 80000;

CREATE TABLE clut (
  key            VARCHAR2(78 BYTE),
  num_key        NUMBER,
  date_modified  DATE,
  padding        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

select segment_name, bytes / (1024 ) as KB, blocks
from user_segments where segment_name like 'CLU%';

insert into clut select key, num_key, date_modified, null from heap ;

set echo off

commit ;

select segment_name, bytes / (1024 ) as KB, blocks
from user_segments where segment_name like 'CLU%';

prompt NOTE: 
prompt The original SIZE and HASHKEYS specified were chosen, 
prompt to make the data fit inside the cluster.

prompt after inserting "expected" data, 
prompt the cluster did not increase in size.
prompt (the pk segment did increase) ...
Prompt  
pause press enter to delete/insert records of about 3x the size...

delete from clut ;
commit ;

insert into clut 
select key, num_key, date_modified
     , lpad ( padding, 300, 'x' ) 
from heap ;
commit ;

select segment_name, bytes / (1024 ) as KB, blocks
from user_segments where segment_name like 'CLU%';

prompt NOTE: 
prompt Inserted records with 3x the size, tripled the rowsize.
prompt Size of cluster increases, what happens to access..
Prompt  
pause press enter to view queries on these large records...

variable vc_key varchar2(100) ;

begin :vc_key := 'THIRTY-EIGHT THOUSAND THREE HUNDRED SEVENTY-THREE'; end;
/
select key from clut where key = :vc_key
/
set autotrace on
/
pause Check Gets, then press enter for next query


begin :vc_key := 'ONE'; end;
/
select key from clut where key = :vc_key
/
pause Check Gets, then press enter for next query

begin :vc_key := 'THIRTY-SEVEN THOUSAND THREE HUNDRED SEVENTY-SEVEN'; end;
/
select key from clut where key = :vc_key
/
pause Check Gets, then press enter for next query

begin :vc_key := 'SIXTEEN THOUSAND TWO HUNDRED TWENTY-TWO'; end;
/
select key from clut where key = :vc_key
/

set autotrace off
set echo off

prompt NOTE: 
prompt (on my system) of these selects, 
prompt some needed 2 or even 3 gets.
prompt If the records grow in size, the advantage dissapears..

Prompt
prompt Notes to self: 
prompt - what happens if the table is analyzed before queries (same result, and chaincount = 0)..
prompt - re-test on 11.1 and 11.2 (same results)
prompt
prompt check blog entries by Jonathan Lewis and ppt from Steve Adams
prompt for more details on what happens with mis-estimates.
prompt
pause press enter to continue 

