
-- copied from internet: 
-- this qry does not indentify the type of temp-usage,
-- and notably not (yet) the use of GTTs by sessions

--
-- alternatively: check v$lock.id1 for locks on a given GTT.
--
/*
select * from v$lock
where id1 in (
select object_id from dba_objects 
where object_name like 'KOST%' 
)         
*/


SELECT   b.TABLESPACE 
       , b.segfile# 
       , b.segblk# 
       , ROUND (  (  ( b.blocks * p.VALUE ) / 1024 / 1024 ), 2 ) size_mb 
       , a.SID 
       , a.serial# 
       , a.username 
       , a.osuser 
       , a.program 
       , a.status 
    FROM v$session a 
       , v$sort_usage b 
       , v$process c 
       , v$parameter p 
   WHERE p.NAME = 'db_block_size' 
     AND a.saddr = b.session_addr 
     AND a.paddr = c.addr 
ORDER BY b.TABLESPACE 
       , b.segfile# 
       , b.segblk# 
       , b.blocks;
       