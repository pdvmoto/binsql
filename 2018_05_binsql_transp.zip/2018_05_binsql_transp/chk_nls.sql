
doc
	chk_nls.sql : Relevant init-parameters 

#


set pagesize 75

column name		format A35 trunc
column value		format A15 wrap
column nls_value	format A30 wrap
column dflt		format A4 justify left
column Sesmod		format A6 trunc head sesmod justify right
column sysmod		format A6 trunc head sysmod justify right

column descript		format A26 trunc


	   
doc

	Nls and date related parameters.
#
SELECT 	p.name				
  , decode (type
           , 3, to_char ( to_number ( value), '99,999,999,999' )
           , 6, to_char ( to_number ( value), '99,999,999,999' ) 
           , value 
           )                                                          value
  , 	decode ( p.ISDEFAULT      , 'TRUE'  , ''      , '  No' )      dflt
  ,     decode ( isses_modifiable , 'TRUE'  , '  Yes' , 'FALSE', '')  sesmod
  ,     decode ( issys_modifiable , 'FALSE' , ''
                                  , issys_modifiable )                sysmod
--  , 	substr ( p.DESCRIPTION, 1 , 23 ) || '...'		      descript
FROM v$parameter p
WHERE 1 = 1
and (      (p.name Like 'nls%') 
	OR (p.name Like '%char%')	   
	OR (p.name Like '%date%')	   
	)
ORDER BY p.name
/

doc
	and additional nls_parameters
#
select parameter name
     , value 	 nls_value 
from v$nls_parameters ;
