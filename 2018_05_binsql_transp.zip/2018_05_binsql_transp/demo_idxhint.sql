
/*
file : demo_idxhint

Essence of a hint: force something..:
 - foce CBO to use an index...
 - test : use any index, no matter which

*/


--alter session set optimizer_mode = first_rows;

set autotrace off
set echo on
set pagesize 100
set linesize 100

column owner       format A15
column table_name  format A30 
column iot_type    format A15
column iot_name    format A30


spool iot_demo

-- drop and recreate the table with a 2-field PK, typical parent-child.

drop   table ovl;
create table ovl as 
select OWNER, TABLE_NAME, TABLESPACE_NAME, IOT_TYPE, IOT_NAME, NUM_ROWS, AVG_ROW_LEN, LAST_ANALYZED, STATUS
from all_tables order by dbms_random.value ;
create unique index ovl_pk on ovl ( owner, table_name );
alter table ovl add constraint ovl_pk primary key ( owner, table_name ) using index ovl_pk ;

select count (*) from ovl;

--
-- Notice: 
-- Just a table. 
-- Imagine a normal Parent-Child set of data.
--

accept press_enter prompt "press enter to continue..."


select owner, count (*) from ovl group by owner ;

--
-- Notice: 
-- Generally DBSMNP has 20-something tables... 
-- A small subset of the total. 
--
-- But when accessed by parent-key,
-- in the worst case we have 20-some times 
-- an index-by-rowid into the table...
-- 

accept press_enter prompt "press enter to continue..."


select 
		owner, tablespace_name, table_name  
	from	
		ovl
	where 	owner = 'DBSNMP'
	order   by 
		owner, table_name
/
select * from table(dbms_xplan.display_cursor(null,null,'BASIC LAST'));

--
-- Notice: 
-- access can be FTS becasue table is small..
-- 

accept press_enter prompt "press enter to continue..."



set autotrace on stat
select 
		owner, tablespace_name, table_name  
	from	
		ovl
	where 	owner = 'DBSNMP'
	order   by 
		owner, table_name
/
set autotrace off

--
-- notice: 
-- the number of consistent gets... 
-- on FTS the gets are the nr of block sin table, 
-- 
-- now force an index..
--
accept press_enter prompt "press enter to continue..."

--
set autotrace on
select /*+ index ( ovl ) */  
		owner, tablespace_name, table_name  
	from	
		ovl ovl
	where 	owner = 'DBSNMP'
	order   by 
		owner, table_name
/
set autotrace off


