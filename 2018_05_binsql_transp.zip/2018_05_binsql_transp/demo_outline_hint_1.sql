/*
 demo of how to catch an outline form dbms_xplan and use it as hint
*/


set linesize 100
set pagesize 100
set echo on

set sqlprompt "SQL> " 

spool demo_outline_hint

clear screen   


-- 
-- Demo of how to "catch" a hint.
-- 


select e.ename, d.dname
from emp  e 
   , dept d
where  e.ename   like 'M%' 
and    e.deptno = d.deptno
/

accept anykey prompt "press any (enter) key..."

select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--  
-- some innocent statement, doing Full Table scans,
-- but I dont like FTS much...
-- 

accept anykey prompt "press any (enter) key..."

clear screen   

--
-- Now, I Force the optimizer to choose my kind of plan (bad practice!).
--

alter session set optimizer_mode=first_rows ;

-- 
--  

accept anykey prompt "press any (enter) key..."

select e.ename, d.dname
from emp  e 
   , dept d
where e.deptno = d.deptno
/

--
-- Same query, same results, 
-- but the plan might be different...
--
accept anykey prompt "press any (enter) key..."

select * from table(dbms_xplan.display_cursor('',null,'BASIC OUTLINE'));        

--
-- I have used dbms_xplan.display_cursor('',null,'BASIC OUTLINE')
--
-- Have a look at the plan (is this what I want ?) ...
-- Have a look at the Outline Data (now that is a Hint!) ...
--
-- I can copy that hint from dbms_xplan and paste it into my SQL...
--  

accept anykey prompt "press any (enter) key..."

clear screen   

--
-- I set the optimizer back to default 
--

alter session set optimizer_mode=choose ;

--
--

accept anykey prompt "press any (enter) key..."


select 
/*+
    BEGIN_OUTLINE_DATA
    IGNORE_OPTIM_EMBEDDED_HINTS
    OPTIMIZER_FEATURES_ENABLE('10.2.0.3')
    FIRST_ROWS
    OUTLINE_LEAF(@"SEL$1")
    FULL(@"SEL$1" "E"@"SEL$1")
    INDEX_RS_ASC(@"SEL$1" "D"@"SEL$1" ("DEPT"."DEPTNO"))
    LEADING(@"SEL$1" "E"@"SEL$1" "D"@"SEL$1")
    USE_NL(@"SEL$1" "D"@"SEL$1")
    END_OUTLINE_DATA
*/
e.ename, d.dname
from emp  e 
   , dept d
where e.deptno = d.deptno
/

--
-- This SQL just ran with a huge HINT (e.g. the outline)
-- have a look at the plan...
-- 

accept anykey prompt "press any (enter) key..."

select * from table(dbms_xplan.display_cursor('',null,'BASIC'));        

--
-- ...and the hint forced it into the plan I wanted 
-- (and I probably got it wrong: I tweaked it into a sub-optimal plan!)
--
-- 
--  ----- summary ----- 
--
-- You can use DBMS_XPLAN to pick up "outlines"
-- and use them as hints to force a certain path.
-- 
-- But you may end up with long-term in-efficiencies.
-- It is now your responsability to make sure your query is "efficient"
--

spool off
