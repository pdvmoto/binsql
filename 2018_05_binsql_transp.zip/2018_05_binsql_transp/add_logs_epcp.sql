-- 
rem how to add or change log-files/groups to a db.
rem
rem run stmnts one by one, to make sure they dont "error",
rem on error: switch-logfile and re-try.
rem 
Alter database add logfile group 4 
( '/oracle/db/epcp/data/rd01/redo04a.rdo'
, '/oracle/db/epcp/data/rd02/redo04b.rdo' ) size 100M ;

alter database drop logfile group 1 ;

Alter database add logfile group 1 
( '/oracle/db/epcp/data/rd01/redo01a.rdo'
, '/oracle/db/epcp/data/rd02/redo01b.rdo' ) size 100M ;

alter database drop logfile group 2 ;

Alter database add logfile group 2 
( '/oracle/db/epcp/data/rd01/redo02a.rdo'
, '/oracle/db/epcp/data/rd02/redo02b.rdo' ) size 100M ;

alter database drop logfile group 3 ;

Alter database add logfile group 3 
( '/oracle/db/epcp/data/rd01/redo03a.rdo'
, '/oracle/db/epcp/data/rd02/redo03b.rdo' ) size 100M ;

alter system switch logfile ;
alter system switch logfile ;
alter system switch logfile ;

alter system checkpoint ;  -- only in 10.x


-- create pfile='initepcp.ora' from spfile;

