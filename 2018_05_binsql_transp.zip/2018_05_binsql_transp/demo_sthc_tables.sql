
set linesize 120
set pagesize 0
set echo on

drop table   heap ;
drop table   iotb ;
drop table   clut ;
drop cluster clu ;

-- first the heap

CREATE TABLE HEAP
(
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
);


insert into heap 
select 
  to_char (to_date ( rownum, 'J'), 'JSP' )  as key  --note the non-random distribution of the key
, rownum  as num_key
, sysdate +  ( dbms_random.value ( -100.0, 100.0) ) as date_modified
, rpad ( to_char ( dbms_random.value ) || ' ' || to_char ( dbms_random.value ), 20 )  as padding
from dual 
connect by level < ( 64 * 1024)
/

create unique index heap_pk on heap ( key ) ;
alter table heap add constraint heap_pk primary key ( key )  ;

-- now IOT
CREATE TABLE IOTB
(
  KEY            VARCHAR2(78 BYTE),
  NUM_KEY        NUMBER,
  DATE_MODIFIED  DATE,
  PADDING        VARCHAR2(300 BYTE)
, constraint iotb_pk primary key ( key)
)
organization index
/

insert into iotb select * from heap ;

-- cluster
CREATE CLUSTER clu ( key varchar2(78 byte) ) 
  SINGLE TABLE 
    SIZE 100
HASHKEYS 80000;

CREATE TABLE clut (
  key            VARCHAR2(78 BYTE),
  num_key        NUMBER,
  date_modified  DATE,
  padding        VARCHAR2(300 BYTE)
, constraint clut_pk primary key ( key)
)
    CLUSTER clu ( key );

insert into clut select * from heap ;
commit ;

exec dbms_stats.gather_table_stats ( ownname => user , tabname => 'HEAP' ); 
exec dbms_stats.gather_table_stats ( ownname => user , tabname => 'IOTB' ); 
exec dbms_stats.gather_table_stats ( ownname => user , tabname => 'CLUT' ); 



