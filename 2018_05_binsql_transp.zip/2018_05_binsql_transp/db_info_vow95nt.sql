prompt No correct database or OS version could be determined. 
prompt Please report to CMG ORC (+31 70 3029333).

@db_info_v9w95nt.sql