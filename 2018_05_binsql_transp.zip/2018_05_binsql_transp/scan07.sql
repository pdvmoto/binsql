set doc off
/* 
	remark:
	- not created as package, do not leave objects in customer database.
			
*/
set doc on

doc
    scan07.sql

    Find heavy shared pool usage (Top 15's):
    esp. on cpu-bottleneck, try to avoid (re)load in shared-pool of
    Tables, Indexes, Packages and Package Bodies.
    - find largest objects, 
    - find most loaded objects
    - find most executed objects
    actions:
    - set shared_pool_reserved_size >= sum of large and most used objects
    - set shared_pool_reserved_min_alloc <= smallest of the large objects
    - any object appearing in more then 1 list is candidate for pinning.
      Use  sys.dbms_shared_pool.keep(object_name);  to pin an object.
#

set serveroutput on
set feedback off

declare 
	-- largest objects 
    cursor c1 is
    select		rpad ( oc.owner, 									 	 12 )
    || ' ' ||	rpad ( oc.name, 				                      	 25 )
    || ' ' ||	substr ( rpad ( decode ( oc.type, 'PACKAGE BODY', 'BODY'
	, oc.type					)
    							, 20 ),		                       	1,	  6 )
	|| ' ' ||	lpad ( to_char ( oc.sharable_mem, 	'9,999,999' ),		 10 )
	|| ' ' ||	lpad ( to_char ( oc.loads, 		'9,999,999' ),		 10 )
	|| ' ' ||	lpad ( to_char ( oc.executions, 	'9,999,999' ),		 10 )
	from                v$db_object_cache	oc
        where oc.type IN ('TABLE', 'INDEX', 'PACKAGE', 'PACKAGE BODY' ) -- Pinnable objects
	order by            oc.sharable_mem 	desc ;
	
	-- loads per obj
	cursor c2 is
    select		rpad ( oc.owner, 									 	 12 )
    || ' ' ||	rpad ( oc.name, 				                      	 25 )
    || ' ' ||	substr ( rpad ( decode ( oc.type, 'PACKAGE BODY', 'BODY'
    											, oc.type
    									)
    							, 20 ),		                       	1,	  6 )
	|| ' ' ||	lpad ( to_char ( oc.sharable_mem, 	'9,999,999' ),		 10 )
	|| ' ' ||	lpad ( to_char ( oc.loads, 			'9,999,999' ),		 10 )
	|| ' ' ||	lpad ( to_char ( oc.executions, 	'9,999,999' ),		 10 )
	from                v$db_object_cache	oc
        where oc.type IN ('TABLE', 'INDEX', 'PACKAGE', 'PACKAGE BODY' ) -- Pinnable objects
	order by            oc.loads 	desc ;

	-- execs per object
	  cursor c3 is
    select		rpad ( oc.owner, 									 	 12 )
    || ' ' ||	rpad ( oc.name, 				                      	 25 )
    || ' ' ||	substr ( rpad ( decode ( oc.type, 'PACKAGE BODY', 'BODY'
    											, oc.type
    									)
    							, 20 ),		                       	1,	  6 )
	|| ' ' ||	lpad ( to_char ( oc.sharable_mem, 	'9,999,999' ),		 10 )
	|| ' ' ||	lpad ( to_char ( oc.loads, 			'9,999,999' ),		 10 )
	|| ' ' ||	lpad ( to_char ( oc.executions, 	'9,999,999' ),		 10 )
	from                v$db_object_cache	oc
        where oc.type IN ('TABLE', 'INDEX', 'PACKAGE', 'PACKAGE BODY' ) -- Pinnable objects
	order by            oc.executions	desc ;

        n_numrows		number  := 16;
	vc2_text		varchar2 (80) ;
	vc2_title		varchar2 (80) ;
	
begin

	DBMS_OUTPUT.ENABLE( 20000 );
	vc2_title :=
	 	'Owner        Object name               Type   Shared mem      Loads      Execs';

	-- heading, max 80!
	dbms_output.put_line ( '.' );
	dbms_output.put_line ( 
	'Largests objects in shared pool: ' );
	dbms_output.put_line ( vc2_title );
	dbms_output.put_line ( 
	'------------------------------------------------------------------------------' );
	
	open c1;
	fetch c1 into vc2_text ;	
	while 	(		(c1%found					)
		 	and 	(c1%rowcount <  n_numrows 	) ) 
	loop
		dbms_output.put_line ( vc2_text );
		fetch c1 into vc2_text ;
	end loop ;
	close c1;
	
	dbms_output.put_line ( '. ' );
	
	-- now top-10 (re)loads
	
	-- heading, max 80!
	dbms_output.put_line ( '. ' );
	dbms_output.put_line ( 
	'Most loaded objects in shared pool' );	
	dbms_output.put_line ( vc2_title );
	dbms_output.put_line ( 
	'------------------------------------------------------------------------------' );

	open c2;
	fetch c2 into vc2_text ;	
	while 	(		(c2%found					)
		 	and 	(c2%rowcount <  n_numrows 	)
		 	) 
	loop
		dbms_output.put_line ( vc2_text );
		fetch c2 into vc2_text ;
	end loop ;

	close c2;
	dbms_output.put_line ( '. ' );
	
	
	dbms_output.put_line ( '. ' );
	dbms_output.put_line ( 
	'Most executed objects in shared pool' );	
	dbms_output.put_line ( vc2_title );
	dbms_output.put_line ( 
	'------------------------------------------------------------------------------' );

	
	open c3;
	fetch c3 into vc2_text ;	
	while 	(		(c3%found					)
		 	and 	(c3%rowcount <  n_numrows 	)
		 	) 
	loop
		dbms_output.put_line ( vc2_text );
		fetch c3 into vc2_text ;
	end loop ;

	close c3;
	dbms_output.put_line ( '. ' );	
	
end;
/

set feedback on
clear columns
prompt

