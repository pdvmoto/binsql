prompt  IN ONDERSTAAND OVERZICHT STAAN DE GELADEN BLOKKEN VAN DE VERSCHILLENDE FILES
prompt  WELKE OPGENOMEN ZIJN IN DE CACHE VAN ORACLE

rem -- need v$bh defined, mostly from catparr.sql 
rem -- (v$bh was forseen to spot ops block-pings).

/*
break on report
compute sum of AantalMb on report
compute sum of Aantalblokken on report
compute sum of Percentage_in_memory on report
select file#,
       decode(file#,0,'Nog niet toegekende cache ruimte', t.name) name,
       Aantalblokken,
       round(AantalMb*d.value/1024/1024,2) AantalMb,
       round(Percentage_in_memory/c.value*100,2) Percentage_in_memory
from   v$parameter c,
       v$parameter d,
       ( select   a.file#,
                  substr(b.name,1,30) name,
                  count(a.block#) Aantalblokken,
                  count(a.block#) AantalMb,
                  count(a.block#) Percentage_in_memory
       --         count(distinct(a.file#||a.block#)) "Aantal verschillende blokken"
         from     v$bh        a,
                  v$datafile  b
         where    a.file# = b.file#(+)
         group by a.file#, b.name
       ) t
where    c.name = 'db_block_buffers'
  and    d.name = 'db_block_size'
order by substr(name,9)
/

 
SELECT 
  e.SEGMENT_NAME
, Count(b."BLOCK#") nr_blocks
FROM SYS.DBA_EXTENTS e, "V$BH" b
WHERE e.BLOCK_ID <= b."BLOCK#"
and b."BLOCK#" < (e.BLOCK_ID + e.blocks)
AND b."FILE#" = e.FILE_ID
GROUP BY e.SEGMENT_NAME
ORDER BY Count(B."BLOCK#") DESC
/

*/

column object_name format a30 heading 'Object Name'
column object_type format a15 heading 'Object Type'

select object_name
      ,object_type
      ,count(*) blocks
from   v$bh bh
      ,dba_objects o
where  bh.objd = o.data_object_id
group by object_name
        ,object_type
order by blocks
/
