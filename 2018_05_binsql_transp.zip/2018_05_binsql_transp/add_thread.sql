
alter database add logfile thread 2 
group 4 'C:\Oracle\oradata\db02\redo04.log' SIZE 15M  ,
group 5 'C:\Oracle\oradata\db02\redo05.log' SIZE 15M  ;

alter database enable public thread 2 ;

create UNDO TABLESPACE "UNDOTBS2" DATAFILE 'C:\Oracle\oradata\db02\undotbs02.dbf' SIZE 200M 
REUSE AUTOEXTEND ON NEXT  5120K MAXSIZE UNLIMITED;

