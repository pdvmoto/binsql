

-- local / uniform or auto / assm

CREATE TABLESPACE "lu_assm"    
  DATAFILE 'C:\Oracle\oradata\db02\lu_assm_01.dbf'    SIZE  1M REUSE 
  AUTOEXTEND ON NEXT  1m   MAXSIZE 200m 
  EXTENT MANAGEMENT LOCAL 
  uniform size 64k
  SEGMENT SPACE MANAGEMENT  AUTO ;

CREATE TABLESPACE "la_assm"    
  DATAFILE 'C:\Oracle\oradata\db02\la_assm_01.dbf'    SIZE  1M REUSE 
  AUTOEXTEND ON NEXT  1m   MAXSIZE 200m 
  EXTENT MANAGEMENT LOCAL 
  autoallocate
  SEGMENT SPACE MANAGEMENT  AUTO ;
