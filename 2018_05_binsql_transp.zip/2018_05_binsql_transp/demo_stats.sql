
exec dbms_stats.delete_table_stats ('STARUSER', 'W_ROLE_D'); 

EXEC DBMS_STATS.SET_TABLE_PREFS('STARUSER','W_ROLE_D','INCREMENTAL','TRUE');

exec dbms_stats.gather_table_stats ('STARUSER', 'W_ROLE_D'); 
 