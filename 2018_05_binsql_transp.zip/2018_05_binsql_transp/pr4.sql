
set sqlprompt "SQL > " 