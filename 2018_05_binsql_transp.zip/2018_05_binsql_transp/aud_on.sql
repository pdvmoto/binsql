-- audit_on.sql
--
-- Script to use the correct auditing options.
--
-- Note: Run as SYS (Or from svrmgrl as connect internal)
--       First move the AUD$ table (move_aud<SID>.sql)

-- 1. Protect the SYS.AUD$ table (see r_aud.sql for report)
AUDIT insert, update, delete, alter, rename ON sys.aud$ BY ACCESS;

-- 2. Use the following auditing options:
-- Audits all succesfull and unsuccesfull connections to and disconnections
-- from the database, regardless of user.
AUDIT session;

-- 3. Audit DML actions whenever not succesfull per session
-- AUDIT select, insert, update, delete ON default WHENEVER not successful;

-- 4. Audit GRANT and REVOKE statements.
AUDIT system grant, grant procedure, grant sequence, grant table, grant type;

-- 5 audit any DDL statement (needs research)
audit alter any table, view, sequence, materialized view, type on all;

audit create any table ;
audit alter any table ;
audit drop any table ;

/*

select * from sys.audit_actions

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'CREATE%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'ALTER%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'DROP%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'RENAME%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'VALIDATE%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'GRANT%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'REVOKE%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'ANALYZE%'

select 'AUDIT ' || name || ' ;' 
from sys.audit_actions
where name like 'TRUNCATE%'


*/
