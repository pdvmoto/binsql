
@chk_nlslength

desc abc

-- set session-level to char.. and char doesnt show in desc.
alter session set nls_length_semantics=char ;

desc abc


-- set session-level to Byte.. and char does! show in desc.
alter session set nls_length_semantics=byte ;

desc abc


