
column table_name    format A10
column num_rows      format 99,999,999
column blocks        format 999,999   
column empty_blocks  format 9,999    head empblck
column avg_space     format 9,999    head avgspc
column chain_cnt     format 9,999    head chncnt
column avg_rowlen    format 9,999    head avgrow

column segment_name  format A10
column bytes         format 99,999,999 
column extents	     format 9,999


select 
table_name, num_rows, blocks, empty_blocks, avg_space, chain_cnt, avg_row_len, compression
from user_tables
where table_name like 'ABC%'
order by table_name
/

select 
segment_name,  bytes, blocks, extents
from user_segments
where segment_name like 'ABC%'
order by segment_name
/
