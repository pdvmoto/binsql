rem
rem Script: allroles.sql
rem
rem Usage : Displays all grantees with there granted role and
rem         the privileges off that role.
rem

column grantee   format a20
column via_role  format a25
column privilege format a30

SELECT rp.grantee	grantee
, rp.granted_role	via_role
, sp.privilege		privilege
FROM dba_role_privs 	rp
,	dba_sys_privs	sp
WHERE sp.grantee = rp.granted_role
union
SELECT grantee		grantee
, ' '			via_role
, privilege		priv
FROM dba_sys_privs
ORDER BY 1, 3
/
