
spool demo_colstats

set timing on
set echo on
set autotrace on stat

SELECT  
owner, histogram, COUNT (*) 
FROM DBA_TAB_COL_STATISTICS
GROUP BY owner, histogram 
ORDER BY owner, histogram 
/

/

accept pressany prompt "press any key..."

SELECT /*+ RULE */  owner, histogram, COUNT (*) 
FROM DBA_TAB_COL_STATISTICS
GROUP BY owner, histogram 
ORDER BY owner, histogram 
/

/

accept pressany prompt "press any key..."

spool off

