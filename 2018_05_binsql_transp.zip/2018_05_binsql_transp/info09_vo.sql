prompt
prompt Script info09.sql is not available in Oracle 7, 8 or 9. It only runs in 10g or 11g.
prompt