
rem show locks
rem the "to_kill" column can be used in :
rem ALTER SYSTEM KILL SESSION 'a,b' ;

set linesize 100

COLUMN to_kill          FORMAT          a42
COLUMN usernm           FORMAT          a10
COLUMN os_usr           FORMAT          a8
COLUMN sid              FORMAT          999
COLUMN a_sid            FORMAT          999
COLUMN ux_pid           FORMAT          99999
COLUMN locked           FORMAT          A10
COLUMN id_1             FORMAT         9999
COLUMN id_2             FORMAT          9999


doc 

SELECT 'alter system kill session '''
       || ses.SID || ',' || ses.serial# || ''' ;   /* '    to_kill
,      ses.username                                      usernm
,      NVL ( obj_1.OBJECT_NAME, '- no locks -' )         locked
,      '*/ '
FROM
  SYS.DBA_OBJECTS       obj_1
, SYS."V_$LOCK"         l
, SYS."V_$SESSION"      ses
WHERE   l.ID1        =  obj_1.OBJECT_ID    (+)
AND     l.SID   (+)  = ses.SID
and	l.type       <> 'MR'
ORDER BY username;

#

-- faster version :
SELECT 'alter system kill session '''
       || ses.SID || ',' || ses.serial# || ''' ;   /* '    to_kill
,      ses.username                                      usernm
,      NVL ( obj_1.OBJECT_NAME, '- no locks -' )         locked
,      '*/ '
FROM
  SYS.DBA_OBJECTS       obj_1
, SYS."V_$LOCK"         l
, SYS."V_$SESSION"      ses
WHERE   l.ID1        =  obj_1.OBJECT_ID  
AND     l.SID        = ses.SID
and	l.type       <> 'MR'
ORDER BY username;

-- the RDS version

COLUMN to_kill          FORMAT          a52

SELECT 
'exec rdsadmin.rdsadmin_util.kill( '
       || ses.SID || ',' || ses.serial# || '); /*'       to_kill
,      ses.username                                      usernm
,      NVL ( obj_1.OBJECT_NAME, '- no locks -' )         locked
,      '*/ '
FROM
  SYS.DBA_OBJECTS       obj_1
, SYS."V_$LOCK"         l
, SYS."V_$SESSION"      ses
WHERE   l.ID1        =  obj_1.OBJECT_ID  
AND     l.SID        = ses.SID
and	l.type       <> 'MR'
ORDER BY username;
