
doc
	spin_lio.sql : generate lIO for &1 sec

notes:
	- beware using views: CPU will spin on auth$ and join-efforts.
	- create sparse table and scan it many times.

-- instead: generat something of max 10K rows, and make it sparse.
create table spin_lio 
pctfree 99 pctused 1
as (select * from dba_objects where rownum < 10000 )
(check that resulting table fits into db_cache easily)


#


-- select to_char ( sysdate, 'HH24:MI:SS' ) from dual;


declare 
	starttime	date ;
	str 		varchar2(1000);
	x 		number;
begin
  starttime := sysdate ;

    while (sysdate - starttime) < &1 / (24 * 3600) loop

            select count (*) into x from spin_lio ;

            --select /*+ ordered use_nl(b) full(a) full(b) */
            --  count(*) into x
            --  from   all_objects a         ,   all_objects b
            --  where  a.owner = b.owner   and   rownum <= 100000 ; 

    end loop; -- while

end ;
/

-- select to_char ( sysdate, 'HH24:MI:SS' ) from dual;

--@sleep &1

--select to_char ( sysdate, 'HH24:MI:SS' ) from dual;

