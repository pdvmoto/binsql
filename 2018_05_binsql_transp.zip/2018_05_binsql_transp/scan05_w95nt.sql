doc
    scan05_w95nt.sql script
    
    Display IO per datafile, Drive (W95/NT) and Tablespace
#

column  brk    noprint    
column  datafile   format a46
column  mountpoint format a46 Heading 'DRIVE (W95/NT)'
column  tablespace format a46
column  Reads      format 99999990
column  Writes     format 99999990
column  R_Perc     format 999.0
column  W_Perc     format 999.0

set heading on
set feedback off
set pagesize 100

select substr(F.file_name,1,instr(F.file_name,'\',-1)) Brk,
       replace(F.file_name,'.dbf','') datafile, 
       S.phyblkrd  Reads,  round((S.phyblkrd  / R.value) * 100,1) R_Perc,
       S.phyblkwrt Writes, round((S.phyblkwrt / W.value) * 100,1) W_Perc
from   sys.v_$filestat S,
       sys.v_$sysstat R,
       sys.v_$sysstat W,
       sys.dba_data_files F
where  F.file_id = S.file# (+)
and    R.name = 'physical reads'
and    W.name = 'physical writes'
order  by 1
/

select substr(F.file_name,1,instr(F.file_name,'\',-1)) mountpoint,
       sum(S.phyblkrd)  Reads,  
       round((sum(S.phyblkrd) / min(R.value) ) * 100,1) R_Perc,
       sum(S.phyblkwrt) Writes, 
       round((sum(S.phyblkwrt) / min(W.value) ) * 100,1) W_Perc
from   sys.v_$filestat S,
       sys.v_$sysstat R,
       sys.v_$sysstat W,
       sys.dba_data_files F
where  F.file_id = S.file# (+)
and    R.name = 'physical reads'
and    W.name = 'physical writes'
group  by substr(F.file_name,1,instr(F.file_name,'\',-1))
order  by 1
/

break on Brk  skip 1 on report
compute sum of Reads  on report 
compute sum of Writes on report

select F.tablespace_name tablespace,
       sum(S.phyblkrd)  Reads,  
       round((sum(S.phyblkrd) / min(R.value) ) * 100,1) R_Perc,
       sum(S.phyblkwrt) Writes, 
       round((sum(S.phyblkwrt) / min(W.value) ) * 100,1) W_Perc
from   sys.v_$filestat S,
       sys.v_$sysstat R,
       sys.v_$sysstat W,
       sys.dba_data_files F
where  F.file_id = S.file# (+)
and    R.name = 'physical reads'
and    W.name = 'physical writes'
group  by F.tablespace_name
order  by 1
/

clear breaks
set feedback on
set pagesize 14
prompt
