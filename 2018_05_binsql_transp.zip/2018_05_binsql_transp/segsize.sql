
-- segsize : find segment size for segments like NAME%

variable param    varchar2(64) ; 
variable segowner varchar2(32) ;  
variable segname  varchar2(32) ; 

/*
select '&1' as param
, instr ('&1', '.' )  pos_of_dot
, upper ( substr ( '&1', 0, (instr ('&1', '.') - 1)  ) ) as segowner
, upper ( substr ( '&1', (instr ('&1', '.') + 1)    ) )as segname
from dual ;


select '&1' par1
, '&2' par2 
from dual ;

select :param as param
, instr (:param, '.' )  pos_of_dot
, upper ( substr ( :param, 0, (instr (:param, '.') - 1)  ) ) as segowner
, upper ( substr ( :param, (instr (:param, '.') + 1)    ) )as segname
from dual ;
*/

-- peel off the parameter... determine schema + object(s)
begin

  :param := '&1' ; 

  select 
    upper ( substr ( :param, 0, (instr (:param, '.') - 1)  ) )      as segowner
  , upper ( substr ( :param, (instr (:param, '.') + 1)    ) ) ||'%' as segname
  into :segowner, :segname
  from dual ;

  select nvl ( :segowner, user) into :segowner
  from dual ; 

end ;
/


select  -- :param arg1, :segowner, :segname , 
'looking for : [' || :segowner || '.' || :segname || ']' as verify
from dual ; 



column table_name    format A10
column num_rows      format 99,999,999
column blocks        format 999,999   
column empty_blocks  format 9,999    head empblck
column avg_space     format 9,999    head avgspc
column chain_cnt     format 9,999    head chncnt
column avg_rowlen    format 9,999    head avgrow

column segment_name     format A20
column partition_name   format A25
column bytes         format 99,999,999 
column kbytes        format 99999999 
column extents	     format 9,999

set verify off

/*
Wishlist:
 - enter user.obj, use upper(beforedot) = owner and upper (afterdot||%) like object
 - enter schema as well..

*/

select 
table_name, num_rows, blocks, empty_blocks, avg_space, chain_cnt, avg_row_len, compression
from DBA_tables
where table_name like :segname
and owner = :segowner
order by table_name
/

select 
segment_name,  partition_name, bytes / 1024 as kbytes, blocks, extents
from dba_segments
where segment_name like :segname
and owner = :segowner
order by segment_name, partition_name
/


select 
  'Total ' as segment_name, ' ' as partition_name
--, segment_name            ,  partition_name
, sum ( bytes / 1024 ) as kbytes
, sum ( blocks ) as blocks
, sum (extents ) as extents
from dba_segments
where segment_name like :segname
and owner = :segowner
--group by 'Total ', ' ' 
/



